Overview:
The game program Three Trios, made with the MVC architecture, is a card game about two players
placing cards on a grid and having them battle until the grid is filled, and a player wins by
having the most owned cards(and a tie if no such player exists).

Quick start:
public ThreeTriosModel(ArrayList<Card> deck, IGrid grid) {
  //Exceptions
  int numHoles = 0;
  for (int i = 0; i < gridCells.size(); i ++) {
    if (gridCells.get(i) instanceof Hole) {
      numHoles++;
    }
  }
  if (deck.size() < gridCells.size() - numHoles) {
    throw new IllegalStateException("Not enough cards for the grid!");
  }

  //Implementation
  this.grid = grid;
  this.deck = deck;
  dealDeck();
}

Key components:
In the current iteration of the ThreeTriosGame code, there are 6 key components, the ThreeTriosModel
and the ThreeTriosView, Player, Card, Grid, and Cell. The ThreeTriosModel represents the core of the
game, think of the clogs in a clock. It takes several of the subcomponents and implements them in
order to create the main logic of the game. Then, there is ThreeTriosView, which is the way the
player perceives the program/model, think of the face of a clock that tells you the time.
It takes several parts of the subcomponents and then uses them to generate a textual view
of the game. Player and its corresponding class represents the participants of the game. Card
represents the main playing object of the game. Grid and Cell both represent the game board of
ThreeTrios and have various functionalities built into them such as Cell having the card battling
logic and the grid being able to enact that logic.

Key subcomponents:
In the current iteration of ThreeTriosGame, there 3 main subcomponents that are used, those being
the cellBattle method in Cell and Grid, switchOwnership in Card, and switchCurrPlayer in
ThreeTriosModel. CellBattle is the method that assists and dictates a core part of the gameplay,
that being the card takeover mechanic, and decides whether a card needs to switch colors or not.
SwitchOwnership is also tied to the same mechanic, except this method is the one that actually does
the switching of colors. Lastly, there is switchCurrPlayer, which controls the player turns.

Source organization:
The program has 2 main folders, src and test. Src is where the main bulk of code is, where there
are 3 files: model, view, controller. Controller contains the ThreeTsController(Unused as of HW5).
Model contains the core workings and logic of the game, including Card, CardImpl, Cell, ICell, Grid,
IGrid, MainPlayer, Player, PlayerColor, Hole, ThreeTriosModel, and ThreeTsModel. View contains the
code that dictates the way the players view the game with ThreeTriosView, and ThreeTsView. Then,
there is the test files, which have model, view, and controller folders which contain tests for
their corresponding src classes.

Changes from Part 2:
We implemented the strategy methods (place to a corner and place based on number of flips), the
score method for the players, and completed the method that determines how many cards can be
flipped by placing a cad down. We also added a constructor that takes in a cardFileReader and a
gridFileReader in order to initialize the games with those methods.

Assignment 6 New Classes and methods:
numCardsCanFlip(Card card, int row, int col):
This method determines how many cards a given card can flip by being placed in a specified position
(row, col) on the grid. It checks for various conditions (valid row/col, valid card, game state)
and simulates the placement of the card on a mock grid to calculate the number of flips that would
occur.
findBestForTopLeft(List<Card> hand): This method finds the best card from the player's hand to
place in the top-left corner based on the card's east and south values. It returns the index of the
best card.
findBestForTopRight(List<Card> hand): Similar to findBestForTopLeft, this method finds the best
card to place in the top-right corner, considering the card's west and south values.
findBestForBottomLeft(List<Card> hand): This method selects the best card to place in the
bottom-left corner by evaluating the card's east and north values.
findBestForBottomRight(List<Card> hand): Finds the best card for the bottom-right corner, based on
the card's west and south values.
cornerPlay(): This method executes the "corner play" strategy where the current player places their
best card in one of the four corners of the grid (top-left, top-right, bottom-left, or
bottom-right). It checks if a corner is empty before placing the card.
flipPlay(): This method is the "flip play" strategy. It selects the card from the player's hand
that can flip the most cards and places it on the grid. If there’s a tie in the number of flips,
it uses the card with the lowest index in the grid.
maxFlips(Card card): Determines the maximum number of flips a given card can cause if placed
anywhere on the grid. It iterates through all grid positions to calculate the maximum number of
flips.
maxFlipsRow(Card card): Returns the row where the maximum number of flips would occur for a given
card. It searches through the grid and checks which position gives the most flips.
maxFlipsCol(Card card): Similar to maxFlipsRow, this method returns the column where the card will
flip the most cards.
ThreeTsGUI: Interface that represents the graphical user interface of the ThreeTrios game.
ThreeTriosGUI: Class that implements ThreeTsGUI and represents the graphical user interface of the
ThreeTrios Game.
ThreeTrios: Class that contains the main method of the ThreeTrios Game project. Activates and runs
the game.
Methods: initializeComponents(), handleCellClick(int row, int col), getCardDisplay(Card card),
updateBoard(), engageBattles().
Helper Methods: performBattle().

Explanation of the controller.
ThreeTriosController
Classes:
-onChangedTurn:
-onGameOver:
-onCardSelect:
-onCellSelect:

PlayerActionListener
Classes
ThreeTriosController: Manages player actions (card and cell selection) and game logic for both human
and AI players in coordination with the model and view.
AIPlayer: Represents the computer-controlled player, implementing decision-making logic for gameplay
based on strategies.

Methods
void onCardSelect(Card card)
Triggered when a player selects a card from their hand.

The card parameter contains details like the card’s name, values (north, south, east, west),
and color.
Used to set the selected card in the game’s state.
void onCellSelect(int row, int col)
Triggered when a player selects a cell in the game grid.

The row and col parameters indicate the location of the selected cell on the grid.
The method handles placing the selected card in the chosen cell and validates moves.
void onChangedTurn(PlayerColor currentPlayer)
Invoked whenever the turn changes between players.

The currentPlayer parameter indicates the color (RED or BLUE) of the player whose turn it is now.
Updates the view and notifies players of the turn change.
void onGameOver(Player winner, int winningScore)
Triggered when the game ends.

The winner parameter provides the details of the player who won (color and score).
The winningScore represents the final score of the winning player.
Displays a game-over message in the GUI and stops the game.
ModelStatusListener
Classes

ThreeTriosModel: Manages the overall game state, including the board configuration,
player turns, score tracking, and event notifications.
ThreeTriosController: Implements listeners to respond to model state changes,
updating the view and managing gameplay actions.
Methods

void onChangedTurn(PlayerColor currentPlayer)
Notifies the listener that the active player has changed.

Updates the game state to reflect whose turn it is and ensures the AI player plays
automatically if it is their turn.
void onGameOver(Player winner, int winningScore)
Indicates that the game has ended, notifying all listeners.

Triggers view updates to display the winner and stops all further interactions in the game.
Game State Updates

Start Game: The model initializes the game board, deals cards to players, and sets the first turn.
Ongoing Game Updates: Listeners receive notifications for score changes,
flipped cards, or other significant game events like battles on the board.
Game Reset or Player Initialization: Resets the game state and re-initializes
the board, cards, and player scores when needed.
