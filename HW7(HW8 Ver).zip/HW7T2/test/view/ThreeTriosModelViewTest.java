package view;

import org.junit.Before;
import org.junit.Test;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Optional;

import model.card.Card;
import model.card.CardImpl;
import model.cell.Cell;
import model.grid.Grid;
import model.cell.ICell;
import model.grid.IGrid;
import model.player.MainPlayer;
import model.player.Player;
import model.player.PlayerColor;
import model.ThreeTriosModel;
import model.ThreeTsModel;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertThrows;

/**
 * represents the tests for the view.
 */
public class ThreeTriosModelViewTest {

  ThreeTsModel model;
  ThreeTsModel emptyModel;
  ThreeTsView view;
  ThreeTsView emptyView;

  Card card1;
  Card card2;
  Card card3;
  Card card4;
  Card card5;
  Card card6;
  Card card7;
  Card card8;
  Card card9;
  Card card10;
  Player redPlayer;
  Player bluePlayer;

  IGrid grid;
  IGrid emptyGrid;
  List<ICell> cells = new ArrayList<>();


  @Before
  public void setUp() {
    // Set up a basic model with a 2x2 grid and two players
    cells.add(new Cell(Optional.of(new CardImpl("hello", 5, 6, 7, 8,
            PlayerColor.RED))));
    cells.add(new Cell(Optional.empty()));
    cells.add(new Cell(Optional.of(new CardImpl("hello", 4, 5, 6, 7,
            PlayerColor.BLUE))));
    cells.add(new Cell(Optional.empty()));

    grid = new Grid(2, 2, cells);
    emptyGrid = new Grid(2, 2, new ArrayList<>(Arrays.asList(
            new Cell(Optional.empty()), new Cell(Optional.empty()),
            new Cell(Optional.empty()), new Cell(Optional.empty()))));
    redPlayer = new MainPlayer(PlayerColor.RED, new ArrayList<Card>(), true, 0);
    bluePlayer = new MainPlayer(PlayerColor.BLUE, new ArrayList<Card>(), false, 0);

    card1 = new CardImpl("hello", 1, 1, 1, 1, PlayerColor.RED);
    card2 = new CardImpl("hello", 1, 2, 1, 10, PlayerColor.RED);
    card3 = new CardImpl("hello", 5, 2, 8, 1, PlayerColor.RED);
    card4 = new CardImpl("hello", 6, 7, 1, 2, PlayerColor.RED);
    card5 = new CardImpl("hello", 4, 4, 2, 1, PlayerColor.RED);

    card6 = new CardImpl("hello", 1, 6, 3, 1, PlayerColor.BLUE);
    card7 = new CardImpl("hello", 9, 2, 1, 5, PlayerColor.BLUE);
    card8 = new CardImpl("hello", 1, 3, 7, 1, PlayerColor.BLUE);
    card9 = new CardImpl("hello", 6, 6, 4, 3, PlayerColor.BLUE);
    card10 = new CardImpl("hello", 1, 1, 1, 1, PlayerColor.BLUE);

    model = new ThreeTriosModel(new ArrayList<Card>(
            Arrays.asList(card1, card2, card3, card4, card5, card6)), grid, redPlayer, bluePlayer);
    emptyModel = new ThreeTriosModel(new ArrayList<Card>(
            Arrays.asList(card1, card2, card3, card4, card5, card6)), emptyGrid, redPlayer,
            bluePlayer);
    view = new ThreeTriosView(model);
    emptyView = new ThreeTriosView(emptyModel);
  }

  @Test
  public void testThreeTriosViewInstantiation() {
    view = new ThreeTriosView(model);
    assertNotNull("ThreeTriosView should not be null after instantiation", view);
  }

  // Add throwing IllegalArgumentException for view if null given
  @Test
  public void testThreeTriosViewInvalidInstantiation() {
    assertThrows(IllegalArgumentException.class, () -> new ThreeTriosView(null));
  }

  @Test
  public void testThreeTriosViewOutput() {
    String expectedOutput = "Player: RED\n"
            + "R _ \n"
            + "B _ \n"
            + "Hand:\n"
            + "hello 1 1 1 1 \n"
            + "hello 5 2 8 1 \n"
            + "hello 4 4 2 1 \n";
    assertEquals("The view's string representation should match the expected output",
            expectedOutput, view.toString());
  }

  @Test
  public void testThreeTriosEmptyGridViewOutput() {
    String expectedOutput = "Player: RED\n"
            + "_ _ \n"
            + "_ _ \n"
            + "Hand:\n"
            + "hello 1 1 1 1 \n"
            + "hello 5 2 8 1 \n"
            + "hello 4 4 2 1 \n"
            + "hello 1 1 1 1 \n"
            + "hello 5 2 8 1 \n"
            + "hello 4 4 2 1 \n";
    assertEquals("The view's string representation should match the expected output",
            expectedOutput, emptyView.toString());
  }
}

