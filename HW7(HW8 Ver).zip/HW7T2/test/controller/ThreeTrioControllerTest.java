package controller;

/**
 * Tests for the controller.
 */
public class ThreeTrioControllerTest {

}
