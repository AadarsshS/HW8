package model;

import org.junit.Before;
import org.junit.Test;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import model.card.Card;
import model.card.CardImpl;
import model.cell.Cell;
import model.cell.Hole;
import model.cell.ICell;
import model.grid.Grid;
import model.grid.IGrid;
import model.player.MainPlayer;
import model.player.Player;

import static model.player.PlayerColor.BLUE;
import static model.player.PlayerColor.RED;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;

/**
 * Test class for the Strategy method.
 */
public class StrategyMethodTest {
  ArrayList<Card> deck = new ArrayList<>();
  ArrayList<Card> deck2 = new ArrayList<>();

  Card card1;
  Card card2;
  Card card3;
  Card card4;
  Card card5;
  Card card11;
  Card card22;
  Card card33;
  Card card44;
  Card card55;

  //first example
  ThreeTriosModel model1;
  List<ICell> gridCells1;
  IGrid grid1;

  Player red1;
  Player blue1;

  //2nd example
  ThreeTriosModel model2;
  List<ICell> gridCells2;
  IGrid grid2;

  Player red2;
  Player blue2;

  //3rd example
  ThreeTriosModel model3;
  List<ICell> gridCells3;
  IGrid grid3;
  Player red3;
  Player blue3;

  //4th example
  ThreeTriosModel model4;
  List<ICell> gridCells4;
  IGrid grid4;

  Player red4;
  Player blue4;

  //4th example
  ThreeTriosModel model5;
  List<ICell> gridCells5;
  IGrid grid5;

  Player red5;
  Player blue5;

  @Before
  public void setUp() {
    //initialize the deck
    deck = new ArrayList<>();

    card1 = new CardImpl("Card1", 5, 5, 5, 5, RED);
    card2 = new CardImpl("Card2", 3, 6, 2, 10, RED);
    card3 = new CardImpl("Card3", 1, 1, 1, 1, RED);
    card4 = new CardImpl("Card4", 5, 7, 6, 4, RED);
    card5 = new CardImpl("Card5", 6, 7, 2, 7, RED);

    deck.add(card1);
    deck.add(card2);
    deck.add(card3);
    deck.add(card4);
    deck.add(card5);

    card11 = new CardImpl("Card11", 1, 1, 1, 1, RED);
    card22 = new CardImpl("Card22", 2, 2, 2, 2, RED);
    card33 = new CardImpl("Card33", 9, 9, 9, 9, RED);
    card44 = new CardImpl("Card55", 9, 9, 9, 9, RED);
    card55 = new CardImpl("Card44", 7, 1, 7, 7, RED);

    deck2.add(card11);
    deck2.add(card22);
    deck2.add(card33);
    deck2.add(card44);
    deck2.add(card55);

    //first example
    gridCells1 = new ArrayList<>();

    gridCells1.add(new Cell(Optional.empty()));
    gridCells1.add(new Cell(Optional.empty()));
    gridCells1.add(new Cell(Optional.empty()));
    gridCells1.add(new Cell(Optional.empty()));
    gridCells1.add(new Cell(Optional.empty()));
    gridCells1.add(new Cell(Optional.empty()));
    gridCells1.add(new Cell(Optional.empty()));
    gridCells1.add(new Cell(Optional.empty()));
    gridCells1.add(new Cell(Optional.empty()));

    grid1 = new Grid(3, 3, gridCells1);

    red1 = new MainPlayer(RED, new ArrayList<>(), true, 0);
    blue1 = new MainPlayer(BLUE, new ArrayList<>(), false, 0);

    model1 = new ThreeTriosModel(deck, grid1, red1, blue1);

    //2nd example
    gridCells2 = new ArrayList<>();

    gridCells2.add(new Hole());
    gridCells2.add(new Cell(Optional.empty()));
    gridCells2.add(new Cell(Optional.empty()));
    gridCells2.add(new Cell(Optional.empty()));
    gridCells2.add(new Cell(Optional.empty()));
    gridCells2.add(new Cell(Optional.empty()));
    gridCells2.add(new Cell(Optional.empty()));
    gridCells2.add(new Cell(Optional.empty()));
    gridCells2.add(new Cell(Optional.empty()));

    grid2 = new Grid(3, 3, gridCells2);

    red2 = new MainPlayer(RED, new ArrayList<>(), true, 0);
    blue2 = new MainPlayer(BLUE, new ArrayList<>(), false, 0);

    model2 = new ThreeTriosModel(deck, grid2, red2, blue2);

    //3rd example
    gridCells3 = new ArrayList<>();

    gridCells3.add(new Hole());
    gridCells3.add(new Cell(Optional.empty()));
    gridCells3.add(new Hole());
    gridCells3.add(new Cell(Optional.empty()));
    gridCells3.add(new Cell(Optional.empty()));
    gridCells3.add(new Cell(Optional.empty()));
    gridCells3.add(new Cell(Optional.empty()));
    gridCells3.add(new Cell(Optional.empty()));
    gridCells3.add(new Cell(Optional.empty()));

    grid3 = new Grid(3, 3, gridCells3);

    red3 = new MainPlayer(RED, new ArrayList<>(), true, 0);
    blue3 = new MainPlayer(BLUE, new ArrayList<>(), false, 0);

    model3 = new ThreeTriosModel(deck, grid3, red3, blue3);

    //4th example
    gridCells4 = new ArrayList<>();

    gridCells4.add(new Hole());
    gridCells4.add(new Cell(Optional.empty()));
    gridCells4.add(new Hole());
    gridCells4.add(new Cell(Optional.empty()));
    gridCells4.add(new Cell(Optional.empty()));
    gridCells4.add(new Cell(Optional.empty()));
    gridCells4.add(new Hole());
    gridCells4.add(new Cell(Optional.empty()));
    gridCells4.add(new Cell(Optional.empty()));

    grid4 = new Grid(3, 3, gridCells4);

    red4 = new MainPlayer(RED, new ArrayList<>(), true, 0);
    blue4 = new MainPlayer(BLUE, new ArrayList<>(), false, 0);

    model4 = new ThreeTriosModel(deck, grid4, red4, blue4);

    //5th example
    gridCells5 = new ArrayList<ICell>();

    gridCells5.add(new Hole());
    gridCells5.add(new Cell(Optional.empty()));
    gridCells5.add(new Cell(Optional.empty()));
    gridCells5.add(new Cell(Optional.empty()));
    gridCells5.add(new Cell(Optional.of(
            new CardImpl("Board1", 5, 8, 6, 7, RED))));
    gridCells5.add(new Cell(Optional.empty()));
    gridCells5.add(new Cell(Optional.of(
            new CardImpl("Board2", 2, 1, 1, 1, RED))));
    gridCells5.add(new Cell(Optional.empty()));
    gridCells5.add(new Cell(Optional.empty()));

    grid5 = new Grid(3, 3, gridCells5);

    red5 = new MainPlayer(RED, new ArrayList<>(), true, 0);
    blue5 = new MainPlayer(BLUE, new ArrayList<>(), false, 0);

    model5 = new ThreeTriosModel(deck2, grid5, red5, blue5);
  }

  @Test
  public void cornerPlayTopLeft() {
    model1.cornerPlay();
    assertEquals(model1.getGrid().getCell(0, 0).getCard().get().getCardName(),
            "Card1");
  }

  @Test
  public void cornerPlayTopRight() {
    model2.switchCurrPlayer();
    model2.cornerPlay();
    assertEquals(model2.getGrid().getCell(0, 2).getCard().get().getCardName(),
            "Card2");
  }

  @Test
  public void cornerPlayBottomLeft() {
    model3.switchCurrPlayer();
    model3.cornerPlay();
    assertEquals(model3.getGrid().getCell(2, 0).getCard().get().getCardName(),
            "Card4");
  }

  @Test
  public void cornerPlayBottomRight() {
    model4.cornerPlay();
    assertEquals(model4.getGrid().getCell(2, 2).getCard().get().getCardName(),
            "Card5");
  }

  @Test
  public void testNumCardsCanFlip() {
    assertEquals(1, model5.numCardsCanFlip(card2, 1, 0));
  }

  @Test
  public void testNumCardsCanFlip2() {
    assertEquals(card2.getColor(), BLUE);

    System.out.println(model5.getGrid().getGridSize());
    assertEquals(2, model5.numCardsCanFlip(card44, 1, 0));
  }

  @Test
  public void testFlipMove() {
    model5.flipPlay();
    assertFalse(model5.getGrid().getCell(0, 1).getCard().isPresent());
    System.out.println(model5.getGrid().getCell(0, 1).getCard().get().getCardName());
    assertTrue(model5.getGrid().getCell(0, 1).getCard().isPresent());
    assertEquals("Card55", model5.getGrid().getCell(0, 1).getCard().get().getCardName());
  }
}
