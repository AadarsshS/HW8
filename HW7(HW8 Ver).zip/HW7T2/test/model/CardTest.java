package model;

import org.junit.Before;
import org.junit.Test;

import java.util.Arrays;
import java.util.List;

import model.card.Card;
import model.card.CardImpl;
import model.player.PlayerColor;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertThrows;

/**
 * represents the card tests.
 */
public class CardTest {

  List<Card> redCards;
  List<Card> blueCards;

  @Before
  public void setUp() {
    redCards = Arrays.asList(
            new CardImpl("Flame Burst", 1, 1, 1, 1, PlayerColor.RED),
            new CardImpl("Blaze Strike", 1, 2, 1, 10,
                    PlayerColor.RED),
            new CardImpl("Inferno", 5, 2, 8, 1,
                    PlayerColor.RED),
            new CardImpl("Fire Spin", 6, 7, 1, 2, PlayerColor.RED),
            new CardImpl("Ember Dance", 4, 4, 2, 1, PlayerColor.RED)
    );

    blueCards = Arrays.asList(
            new CardImpl("Water Splash", 1, 6, 3, 1,
                    PlayerColor.BLUE),
            new CardImpl("Wave Crash", 9, 2, 1, 5, PlayerColor.BLUE),
            new CardImpl("Tidal Force", 1, 3, 7, 1, PlayerColor.BLUE),
            new CardImpl("Aqua Shield", 6, 6, 4, 3, PlayerColor.BLUE),
            new CardImpl("Rainfall", 1, 1, 1, 1, PlayerColor.BLUE)
    );
  }

  @Test
  public void testGetCardName() {
    List<String> expectedNames = Arrays.asList("Flame Burst", "Blaze Strike", "Inferno",
            "Fire Spin", "Ember Dance",
            "Water Splash", "Wave Crash", "Tidal Force", "Aqua Shield", "Rainfall");

    List<Card> allCards =
            Arrays.asList(redCards.get(0), redCards.get(1), redCards.get(2), redCards.get(3),
                    redCards.get(4), blueCards.get(0), blueCards.get(1), blueCards.get(2),
                    blueCards.get(3), blueCards.get(4));

    for (int i = 0; i < allCards.size(); i++) {
      assertEquals(expectedNames.get(i), allCards.get(i).getCardName());
    }
  }

  @Test
  public void testGetColor() {
    for (Card card : redCards) {
      assertEquals(PlayerColor.RED, card.getColor());
    }
    for (Card card : blueCards) {
      assertEquals(PlayerColor.BLUE, card.getColor());
    }
  }

  @Test
  public void testGetNorth() {
    int[] expectedNorthValues = {1, 1, 5, 6, 4, 1, 9, 1, 6, 1};

    List<Card> allCards = Arrays.asList(redCards.get(0), redCards.get(1), redCards.get(2),
            redCards.get(3), redCards.get(4),
            blueCards.get(0), blueCards.get(1), blueCards.get(2), blueCards.get(3),
            blueCards.get(4));

    for (int i = 0; i < allCards.size(); i++) {
      assertEquals(expectedNorthValues[i], allCards.get(i).getNorth());
    }
  }

  @Test
  public void testGetSouth() {
    int[] expectedSouthValues = {1, 2, 2, 7, 4, 6, 2, 3, 6, 1};

    List<Card> allCards = Arrays.asList(redCards.get(0), redCards.get(1), redCards.get(2),
            redCards.get(3), redCards.get(4),
            blueCards.get(0), blueCards.get(1), blueCards.get(2), blueCards.get(3),
            blueCards.get(4));

    for (int i = 0; i < allCards.size(); i++) {
      assertEquals(expectedSouthValues[i], allCards.get(i).getSouth());
    }
  }

  @Test
  public void testGetEast() {
    int[] expectedEastValues = {1, 1, 8, 1, 2, 3, 1, 7, 4, 1};

    List<Card> allCards = Arrays.asList(redCards.get(0), redCards.get(1), redCards.get(2),
            redCards.get(3), redCards.get(4),
            blueCards.get(0), blueCards.get(1), blueCards.get(2), blueCards.get(3),
            blueCards.get(4));

    for (int i = 0; i < allCards.size(); i++) {
      assertEquals(expectedEastValues[i], allCards.get(i).getEast());
    }
  }

  @Test
  public void testGetWest() {
    int[] expectedWestValues = {1, 10, 1, 2, 1, 1, 5, 1, 3, 1};

    List<Card> allCards = Arrays.asList(redCards.get(0), redCards.get(1), redCards.get(2),
            redCards.get(3), redCards.get(4),
            blueCards.get(0), blueCards.get(1), blueCards.get(2), blueCards.get(3),
            blueCards.get(4));

    for (int i = 0; i < allCards.size(); i++) {
      assertEquals(expectedWestValues[i], allCards.get(i).getWest());
    }
  }

  @Test
  public void testSwitchOwnership() {
    // Assuming `switchOwnership()` toggles the ownership color
    for (Card card : redCards) {
      card.switchOwnership();
      assertEquals(PlayerColor.BLUE, card.getColor());
      card.switchOwnership();
      assertEquals(PlayerColor.RED, card.getColor());
    }

    for (Card card : blueCards) {
      card.switchOwnership();
      assertEquals(PlayerColor.RED, card.getColor());
      card.switchOwnership();
      assertEquals(PlayerColor.BLUE, card.getColor());
    }
  }

  @Test
  public void testNullCardName() {
    assertThrows(IllegalArgumentException.class, () -> {
      new CardImpl(null, 1, 1, 1, 1, PlayerColor.RED);
    });
  }

  @Test
  public void testNullPlayerColor() {
    assertThrows(IllegalArgumentException.class, () -> {
      new CardImpl("Null Color", 1, 1, 1, 1, null);
    });
  }
}
