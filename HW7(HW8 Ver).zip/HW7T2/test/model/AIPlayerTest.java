package model;

/**
 * Tests for the AIPlayer class
 */
public class AIPlayerTest {

}
