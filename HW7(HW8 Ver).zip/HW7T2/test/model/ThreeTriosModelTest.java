package model;

import org.junit.Before;
import org.junit.Test;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Optional;

import java.util.List;

import model.card.Card;
import model.card.CardImpl;
import model.cell.Cell;
import model.cell.Hole;
import model.cell.ICell;
import model.grid.Grid;
import model.grid.IGrid;
import model.player.MainPlayer;
import model.player.Player;

import static model.player.PlayerColor.BLUE;
import static model.player.PlayerColor.RED;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;

/**
 * Tests for the ThreeTrios Model class.
 */

public class ThreeTriosModelTest {

  ThreeTriosModel model;
  List<ICell> gridCells;
  ArrayList<Card> deck = new ArrayList<>();
  IGrid grid;

  Player red;
  Player blue;

  @Before
  public void setUp() {
    gridCells = new ArrayList<>();
    deck = new ArrayList<>();

    gridCells.add(new Hole());
    gridCells.add(new Cell(Optional.empty()));
    gridCells.add(new Cell(Optional.empty()));
    gridCells.add(new Cell(Optional.empty()));
    gridCells.add(new Hole());
    gridCells.add(new Cell(Optional.empty()));
    gridCells.add(new Cell(Optional.empty()));
    gridCells.add(new Cell(Optional.empty()));
    gridCells.add(new Hole());

    grid = new Grid(3, 3, gridCells);

    deck.add(new CardImpl("Flame Burst", 1, 1, 1, 1, RED));
    deck.add(new CardImpl("Blaze Strike", 1, 2, 1, 10, RED));
    deck.add(new CardImpl("Inferno", 5, 2, 8, 1, RED));
    deck.add(new CardImpl("Water Splash", 1, 6, 3, 1, BLUE));
    deck.add(new CardImpl("Wave Crash", 9, 2, 1, 5, BLUE));

    red = new MainPlayer(RED, new ArrayList<>(), true, 0);
    blue = new MainPlayer(BLUE, new ArrayList<>(), false, 0);

    model = new ThreeTriosModel(deck, grid, red, blue);
  }

  //deal deck
  @Test
  public void testDealDeck() {
    assertEquals(3, red.getHand().size());
    assertEquals(2, blue.getHand().size());

    assertTrue(red.getHand().contains(deck.get(0)));
    assertTrue(blue.getHand().contains(deck.get(1)));
    assertTrue(red.getHand().contains(deck.get(2)));
    assertTrue(blue.getHand().contains(deck.get(3)));
  }

  //Switch current player
  @Test
  public void testSwitchCurrPlayer() {
    assertEquals(model.getCurrPlayer().getColor(), RED);
    model.switchCurrPlayer();
    assertEquals(model.getCurrPlayer().getColor(), BLUE);
  }

  //place card
  @Test(expected = IllegalStateException.class)
  public void testPlaceCardWhenGameIsWon() {
    red.getHand().clear();
    model.placeCard(1, 1, deck.get(0));
  }

  @Test(expected = IllegalArgumentException.class)
  public void testPlaceCardNullCard() {
    model.placeCard(1, 1, null); // Null card
  }

  @Test(expected = IllegalStateException.class)
  public void testPlaceCardWhenGameIsOver() {
    // Simulate game over state
    red.getHand().clear(); // Clear red's hand to simulate game over
    model.placeCard(1, 1, deck.get(0)); // Should throw exception since the game is over
  }

  @Test(expected = IllegalArgumentException.class)
  public void testPlaceCardInvalidRow() {
    model.placeCard(-1, 1, deck.get(0)); // Invalid row
  }

  @Test(expected = IllegalArgumentException.class)
  public void testPlaceCardInvalidColumn() {
    model.placeCard(1, -1, deck.get(0)); // Invalid column
  }

  @Test
  public void testPlaceCardValid() {
    red.getHand().add(deck.get(0)); // Adding "Flame Burst"

    model.placeCard(1, 2, deck.get(0));

    assertTrue(grid.getCell(1, 2).getCard().isPresent());
    assertEquals(deck.get(0), grid.getCell(1, 2).getCard().get());
  }


  @Test
  public void testIsGameOverWhenGameWon() {
    model.placeCard(0, 1, deck.get(0));
    model.placeCard(1, 0, deck.get(1));
    model.placeCard(1, 2, deck.get(2));
    model.placeCard(2, 1, deck.get(3));

    assertTrue(model.isGameOver());
  }

  @Test
  public void testIsGameOverWhenHandsEmpty() {
    red.getHand().clear();
    blue.getHand().clear();

    assertTrue(model.isGameOver());
  }

  @Test
  public void testIsGameOverWhenNotWonAndHandsNotEmpty() {
    assertFalse(model.isGameOver());
  }

  @Test
  public void testGetCurrPlayer_ReturnsRedPlayer_WhenRedIsCurrent() {
    Player currentPlayer = model.getCurrPlayer();

    assertEquals(red, currentPlayer);
  }

  @Test
  public void testGetCurrPlayer_ReturnsBluePlayer_WhenBlueIsCurrent() {
    red = new MainPlayer(RED, new ArrayList<>(), false, 0);
    blue = new MainPlayer(BLUE, new ArrayList<>(), true, 0);

    model = new ThreeTriosModel(deck, grid, red, blue);

    Player currentPlayer = model.getCurrPlayer();

    assertEquals(blue, currentPlayer);
  }

  @Test
  public void testGetGrid_ReturnsCorrectGrid() {
    IGrid currentGrid = model.getGrid();

    assertEquals(grid, currentGrid);
    assertEquals(3, currentGrid.getNumRows());
    assertEquals(3, currentGrid.getNumCols());
  }

  @Test
  public void testCardFileReader() throws FileNotFoundException {
    model.cardFileReader("src/model/cardFiles/CardsEnoughForAllBoards.txt");

    assertEquals(20, model.deck.size());

    Card card1 = model.deck.get(0);
    assertEquals("CARD_HAWK", card1.getCardName());
    assertEquals(4, card1.getNorth());
    assertEquals(9, card1.getSouth());
    assertEquals(1, card1.getEast());
    assertEquals(3, card1.getWest());

    Card card2 = model.deck.get(1);
    assertEquals("CARD_PHOENIX", card2.getCardName());
    assertEquals(6, card2.getNorth());
    assertEquals(2, card2.getSouth());
    assertEquals(8, card2.getEast());
    assertEquals(10, card2.getWest());
  }

  @Test
  public void testGridFileReader() throws IOException {
    // Create a temporary grid file
    String tempFilePath = "src/model/gridFiles/AllCellsCanTouchGrid.txt";

    // Read the grid from the file
    model.gridFileReader(tempFilePath);

    // Check the dimensions of the grid
    assertEquals(3, model.getGrid().getNumRows());
    assertEquals(4, model.getGrid().getNumCols());

    // Check specific cells
    assertTrue(model.getGrid().getCell(0, 0) instanceof Hole); // First row, first column
    assertTrue(model.getGrid().getCell(0, 1) instanceof Cell); // First row, second column
    assertTrue(model.getGrid().getCell(0, 2) instanceof Cell); // First row, third column
    assertTrue(model.getGrid().getCell(0, 3) instanceof Hole); // First row, fourth column

    assertTrue(model.getGrid().getCell(1, 0) instanceof Cell); // Second row, first column
    assertTrue(model.getGrid().getCell(1, 1) instanceof Cell); // Second row, second column
    assertTrue(model.getGrid().getCell(1, 2) instanceof Hole); // Second row, third column
    assertTrue(model.getGrid().getCell(1, 3) instanceof Cell); // Second row, fourth column

    assertTrue(model.getGrid().getCell(2, 0) instanceof Cell); // Third row, first column
    assertTrue(model.getGrid().getCell(2, 1) instanceof Cell); // Third row, second column
    assertTrue(model.getGrid().getCell(2, 2) instanceof Cell); // Third row, third column
    assertTrue(model.getGrid().getCell(2, 3) instanceof Cell); // Third row, fourth column

  }

  @Test
  public void testGetNumFlipped() throws FileNotFoundException {
    String tempFilePath = "src/model/gridFiles/AllCellsCanTouchGrid.txt";
    model.gridFileReader(tempFilePath);

    model.placeCard(0, 1,
            new CardImpl("Flame Burst", 1, 1, 1, 1, RED));

    int num = model.numCardsCanFlip(
            new CardImpl(
                    "Wave Crash", 1, 1, 1, 1, BLUE), 0, 1);

    assertEquals(0, num);

    model.placeCard(2, 2,
            new CardImpl("Water Burst", 1, 1, 1, 1, BLUE));

    num = model.numCardsCanFlip(
            new CardImpl(
                    "Wave Crash", 9, 2, 1, 5, BLUE), 1, 1);

    assertEquals(1, num);
  }

  @Test
  public void testScore() {
    for (Card c : model.getRed().getHand()) {
      System.out.print(c.getCardName());
    }
    assertEquals(3, model.getRed().getScore());

    model.placeCard(0, 2,
            (new CardImpl("Wave Crash", 9, 2, 1, 5, RED)));

    for (Card c : model.getRed().getHand()) {
      System.out.print(c.getCardName());
    }

    assertEquals(2, model.getBlue().getHand().size());
    assertTrue(model.getBlue().getIfCurrPlayer());

    model.placeCard(1, 2,
            new CardImpl("Water Splash", 1, 6, 3, 1, BLUE));
    Card card = new CardImpl("Water Splash", 1, 6, 3, 1, BLUE);

    assertEquals(model.getGrid().getCell(1, 2).getCard(), Optional.of(new CardImpl(
            "Water Splash", 1, 6, 3, 1, BLUE)));

    assertEquals(2, model.getRed().getHand().size());
    for (Card c : model.getBlue().getHand()) {
      System.out.print(c.getCardName());
    }
    assertEquals(1, model.getBlue().getHand().size());
  }
}


