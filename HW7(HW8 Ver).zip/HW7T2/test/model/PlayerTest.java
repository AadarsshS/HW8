package model;

import org.junit.Before;
import org.junit.Test;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import model.card.Card;
import model.card.CardImpl;
import model.player.MainPlayer;
import model.player.Player;
import model.player.PlayerColor;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;

/**
 * Tests for the player class.
 */
public class PlayerTest {

  // Players
  private Player player1;
  private Player player2;

  // Cards
  Card card1;
  Card card2;
  Card card3;
  Card card4;
  Card card5;
  Card card6;
  Card card7;
  Card card8;
  Card card9;
  Card card10;

  // Hands
  List<Card> hand1;
  List<Card> hand2;
  List<Card> emptyHand;

  @Before
  public void setUp() {
    card1 = new CardImpl("hello", 1, 1, 1, 1, PlayerColor.RED);
    card2 = new CardImpl("hello", 1, 2, 1, 10, PlayerColor.RED);
    card3 = new CardImpl("hello", 5, 2, 8, 1, PlayerColor.RED);
    card4 = new CardImpl("hello", 6, 7, 1, 2, PlayerColor.RED);
    card5 = new CardImpl("hello", 4, 4, 2, 1, PlayerColor.RED);

    card6 = new CardImpl("hello", 1, 6, 3, 1, PlayerColor.BLUE);
    card7 = new CardImpl("hello", 9, 2, 1, 5, PlayerColor.BLUE);
    card8 = new CardImpl("hello", 1, 3, 7, 1, PlayerColor.BLUE);
    card9 = new CardImpl("hello", 6, 6, 4, 3, PlayerColor.BLUE);
    card10 = new CardImpl("hello", 1, 1, 1, 1, PlayerColor.BLUE);

    hand1 = new ArrayList<>(Arrays.asList(card1, card2, card3, card4, card5));
    hand2 = new ArrayList<>(Arrays.asList(card6, card7, card8, card9, card10));
    emptyHand = new ArrayList<>();

    player1 = new MainPlayer(PlayerColor.RED, hand1, true, 0);
    player2 = new MainPlayer(PlayerColor.BLUE, hand2, false, 0);
  }

  @Test(expected = IllegalArgumentException.class)
  public void testColorIsNullException() {
    Player nullColorPlayer = new MainPlayer(null, hand1, true, 0); // Pass null for color
  }

  @Test
  public void testGetHand() {
    assertEquals(hand1, player1.getHand());
  }

  @Test
  public void testNotCurrentPlayer() {
    assertFalse(player2.getIfCurrPlayer());
  }

  @Test
  public void testIsCurrent() {
    assertTrue(player1.getIfCurrPlayer());
  }
}
