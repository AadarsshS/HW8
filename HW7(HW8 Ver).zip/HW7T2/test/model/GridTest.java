package model;

import org.junit.Before;
import org.junit.Test;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Optional;

import model.card.Card;
import model.card.CardImpl;
import model.cell.Cell;
import model.cell.Hole;
import model.cell.ICell;
import model.grid.Grid;
import model.grid.IGrid;
import model.player.PlayerColor;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertNotEquals;
import static org.junit.Assert.assertTrue;

/**
 * Tests for the grid class.
 */
public class GridTest {
  //cards
  Optional<Card> card1;
  Optional<Card> card2;
  Optional<Card> card3;
  Optional<Card> card4;
  Optional<Card> card5;
  Optional<Card> card6;
  Optional<Card> card7;
  Optional<Card> card8;
  Optional<Card> card9;
  Optional<Card> card10;

  //cells
  ICell cell1;
  ICell cell2;
  ICell cell3;
  ICell cell4;
  ICell cell5;
  ICell cell6;
  ICell cell7;
  ICell cell8;
  ICell cell9;
  ICell cell10;
  ICell empty;

  ICell hole;

  IGrid grid;

  ArrayList<ICell> cells;

  @Before
  public void setUp() {
    card1 = Optional.of(new CardImpl("Flame Burst", 1, 1, 1, 1, PlayerColor.RED));
    card2 = Optional.of(new CardImpl("Blaze Strike", 1, 2, 1, 10, PlayerColor.RED));
    card3 = Optional.of(new CardImpl("Inferno", 5, 2, 8, 1, PlayerColor.RED));
    card4 = Optional.of(new CardImpl("Fire Spin", 6, 7, 1, 2, PlayerColor.RED));
    card5 = Optional.of(new CardImpl("Ember Dance", 4, 4, 2, 1, PlayerColor.RED));

    card6 = Optional.of(new CardImpl("Water Splash", 1, 6, 3, 1, PlayerColor.BLUE));
    card7 = Optional.of(new CardImpl("Wave Crash", 9, 2, 1, 5, PlayerColor.BLUE));
    card8 = Optional.of(new CardImpl("Tidal Force", 1, 3, 7, 1, PlayerColor.BLUE));
    card9 = Optional.of(new CardImpl("Aqua Shield", 6, 6, 4, 3, PlayerColor.BLUE));
    card10 = Optional.of(new CardImpl("Rainfall", 1, 1, 1, 1, PlayerColor.BLUE));

    cell1 = new Cell(card1);
    cell2 = new Cell(card2);
    cell3 = new Cell(card3);
    cell4 = new Cell(card4);
    cell5 = new Cell(card5);
    cell6 = new Cell(card6);
    cell7 = new Cell(card7);
    cell8 = new Cell(card8);
    cell9 = new Cell(card9);
    cell10 = new Cell(card10);

    empty = new Cell(Optional.empty());

    hole = new Hole();

    cells = new ArrayList<ICell>(Arrays.asList(
            cell1, hole, empty, hole, hole,
            cell2, cell3, hole, cell4, hole,
            cell5, hole, hole, cell6, cell7,
            cell8, hole, hole, hole, cell9,
            hole, hole, hole, hole, cell10));
    grid = new Grid(5, 5, cells);
  }

  @Test(expected = IllegalArgumentException.class)
  public void invalidRowWhenConstructing() {
    IGrid grid = new Grid(-1, 5, cells);
  }

  @Test(expected = IllegalArgumentException.class)
  public void invalidColWhenConstructing() {
    IGrid grid = new Grid(5, -1, cells);
  }

  @Test(expected = IllegalArgumentException.class)
  public void invalidCellsWhenConstructing() {
    IGrid grid = new Grid(5, 5, null);
  }

  //placeCard
  @Test(expected = IllegalArgumentException.class)
  public void invalidRowWhenPlaceCard() {
    grid.placeCard(-1, 3, card1.get());
  }

  @Test(expected = IllegalArgumentException.class)
  public void invalidColWhenPlaceCard() {
    grid.placeCard(3, -1, card1.get());
  }

  @Test(expected = IllegalArgumentException.class)
  public void invalidCardWhenPlaceCard() {
    grid.placeCard(3, -1, null);
  }

  @Test(expected = IllegalArgumentException.class)
  public void exceptionWhenPlaceOnHole() {
    grid.placeCard(0, 1, card1.get());
  }

  @Test
  public void placeCard() {
    assertFalse(grid.getCell(0, 2).getCard().isPresent());
    grid.placeCard(0, 2, card1.get());
    assertTrue(grid.getCell(0, 2).getCard().isPresent());
  }

  //get cell
  @Test(expected = IllegalArgumentException.class)
  public void invalidRowGetCell() {
    grid.getCell(-1, 3);
  }

  @Test(expected = IllegalArgumentException.class)
  public void invalidColGetCell() {
    grid.getCell(3, -1);
  }

  @Test
  public void testGetHoleCell() {
    assertEquals(grid.getCell(3, 3), hole);
  }

  @Test
  public void testGetCell() {
    assertEquals(grid.getCell(0, 0), cell1);
  }

  //get cell right
  @Test
  public void testGetRightCellHole() {
    assertEquals(grid.getCellRight(cell1), hole);
  }

  @Test
  public void testGetRightCell() {
    assertEquals(grid.getCellRight(cell2), cell3);
  }

  //get cell left
  @Test
  public void testGetLeftCellHole() {
    assertEquals(grid.getCellLeft(cell10), hole);
  }

  @Test
  public void testGetLeftCell() {
    assertEquals(grid.getCellLeft(cell3), cell2);
  }

  //get cell above
  @Test
  public void testGetAboveCellHole() {
    assertEquals(grid.getCellAbove(cell3), hole);
  }

  @Test
  public void testGetAboveCell() {
    assertEquals(grid.getCellAbove(cell8), cell5);
  }

  //get cell below
  @Test
  public void testGetBelowCellHole() {
    assertEquals(grid.getCellBelow(cell6), hole);
  }

  @Test
  public void testGetBelowCell() {
    assertEquals(grid.getCellBelow(cell5), cell8);
  }

  //cell battle
  @Test
  public void testCellBattle() {
    IGrid gridBeforeBattle = new Grid(5, 5, new ArrayList<>(cells));
    card8.get().switchOwnership();
    grid.cellBattle(cell9);
    assertEquals(cell8.getCard().get().getColor(), PlayerColor.RED);
    assertNotEquals(gridBeforeBattle, grid);
  }

  //get num rows
  @Test
  public void testGetNumRows() {
    assertEquals(grid.getNumRows(), 5);
  }

  //get num cols
  @Test
  public void testGetNumCols() {
    assertEquals(grid.getNumCols(), 5);
  }

  //test the grid size
  @Test
  public void testGetGridSize() {
    assertEquals(grid.getGridSize(), 25);
  }

  @Test
  public void testGetNumBlue() {
    assertEquals(grid.getNumBlue(), 5);
  }

  @Test
  public void testGetNumRed() {
    assertEquals(grid.getNumRed(), 5);
  }
}