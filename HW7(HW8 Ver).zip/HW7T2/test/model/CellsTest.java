package model;

import org.junit.Before;
import org.junit.Test;

import java.util.ArrayList;
import java.util.Optional;

import model.card.Card;
import model.card.CardImpl;
import model.cell.Cell;
import model.cell.ICell;
import model.grid.Grid;
import model.grid.IGrid;
import model.player.PlayerColor;

import static org.junit.Assert.assertEquals;

/**
 * represents the cells for test.
 */
public class CellsTest {

  //cards
  Optional<Card> card1;
  Optional<Card> card2;
  Optional<Card> card3;
  Optional<Card> card4;
  Optional<Card> card5;
  Optional<Card> card6;
  Optional<Card> card7;
  Optional<Card> card8;
  Optional<Card> card9;
  Optional<Card> card10;

  //cells
  ICell cell1;
  ICell cell2;
  ICell cell3;
  ICell cell4;
  ICell cell5;
  ICell cell6;
  ICell cell7;
  ICell cell8;
  ICell cell9;
  ICell cell10;

  ICell hole;

  IGrid grid;

  @Before
  public void setUp() {
    card1 = Optional.of(new CardImpl("Flame Burst", 1, 1, 1, 1, PlayerColor.RED));
    card2 = Optional.of(new CardImpl("Blaze Strike", 1, 2, 1, 10, PlayerColor.RED));
    card3 = Optional.of(new CardImpl("Inferno", 5, 2, 8, 1, PlayerColor.RED));
    card4 = Optional.of(new CardImpl("Fire Spin", 6, 7, 1, 2, PlayerColor.RED));
    card5 = Optional.of(new CardImpl("Ember Dance", 4, 4, 2, 1, PlayerColor.RED));

    card6 = Optional.of(new CardImpl("Water Splash", 1, 6, 3, 1, PlayerColor.BLUE));
    card7 = Optional.of(new CardImpl("Wave Crash", 9, 2, 1, 5, PlayerColor.BLUE));
    card8 = Optional.of(new CardImpl("Tidal Force", 1, 3, 7, 1, PlayerColor.BLUE));
    card9 = Optional.of(new CardImpl("Aqua Shield", 6, 6, 4, 3, PlayerColor.BLUE));
    card10 = Optional.of(new CardImpl("Rainfall", 1, 1, 1, 1, PlayerColor.BLUE));

    cell1 = new Cell(card1);
    cell2 = new Cell(card2);
    cell3 = new Cell(card3);
    cell4 = new Cell(card4);
    cell5 = new Cell(card5);
    cell6 = new Cell(card6);
    cell7 = new Cell(card7);
    cell8 = new Cell(card8);
    cell9 = new Cell(card9);
    cell10 = new Cell(card10);

    hole = new Cell(Optional.empty());

    grid = new Grid(5, 5, new ArrayList<ICell>());
  }

  @Test(expected = IllegalArgumentException.class)
  public void testNullCardException() {
    ICell nullCardCell = new Cell(null);

  }

  //Get card
  @Test
  public void getCardCell() {
    assertEquals(cell1.getCard(), card1);
  }

  @Test
  public void getCardHole() {
    assertEquals(hole.getCard(), Optional.empty());
  }

  //Set Card
  @Test
  public void setCardCell() {
    cell1.setCard(Optional.empty());
    assertEquals(cell1.getCard(), Optional.empty());

    cell1.setCard(card2);
    assertEquals(cell1.getCard(), card2);
  }

  @Test
  public void setCardHole() {
    hole.setCard(card4);
    assertEquals(hole.getCard(), card4);
  }

  //Right Battle
  @Test
  public void testRightBattleTwoCells() {
    cell1.rightBattle(cell9, grid);
    assertEquals(cell1.getCard().get().getColor(), PlayerColor.RED);
    assertEquals(cell9.getCard().get().getColor(), PlayerColor.BLUE);

    cell9.rightBattle(cell1, grid);
    assertEquals(cell1.getCard().get().getColor(), PlayerColor.BLUE);
    assertEquals(cell9.getCard().get().getColor(), PlayerColor.BLUE);
  }

  @Test
  public void testRightBattleTwoCellsTie() {
    cell1.rightBattle(cell10, grid);
    assertEquals(cell1.getCard().get().getColor(), PlayerColor.RED);
    assertEquals(cell10.getCard().get().getColor(), PlayerColor.BLUE);
  }

  @Test
  public void testRightBattleTwoHoles() {
    hole.rightBattle(hole, grid);
    assertEquals(hole.getCard(), Optional.empty());

  }

  @Test
  public void testRightBattleOneHoleOneCell() {
    cell1.rightBattle(hole, grid);
    assertEquals(cell1.getCard(), card1);

  }

  //Left Battle
  @Test
  public void testLeftBattleTwoCells() {
    cell1.leftBattle(cell9, grid);
    assertEquals(cell1.getCard().get().getColor(), PlayerColor.RED);
    assertEquals(cell9.getCard().get().getColor(), PlayerColor.BLUE);

    cell9.leftBattle(cell1, grid);
    assertEquals(cell1.getCard().get().getColor(), PlayerColor.BLUE);
    assertEquals(cell9.getCard().get().getColor(), PlayerColor.BLUE);

  }

  @Test
  public void testLeftBattleTwoCellsTie() {
    cell1.leftBattle(cell10, grid);
    assertEquals(cell1.getCard().get().getColor(), PlayerColor.RED);
    assertEquals(cell10.getCard().get().getColor(), PlayerColor.BLUE);
  }

  @Test
  public void testLeftBattleTwoHoles() {
    hole.leftBattle(hole, grid);
    assertEquals(hole.getCard(), Optional.empty());
  }

  @Test
  public void testLeftBattleOneHoleOneCell() {
    cell1.leftBattle(hole, grid);
    assertEquals(cell1.getCard(), card1);
  }

  //Above Battle
  @Test
  public void testAboveBattleTwoCells() {
    cell10.aboveBattle(cell4, grid);
    assertEquals(cell10.getCard().get().getColor(), PlayerColor.BLUE);
    assertEquals(cell4.getCard().get().getColor(), PlayerColor.RED);

    cell4.aboveBattle(cell10, grid);
    assertEquals(cell4.getCard().get().getColor(), PlayerColor.RED);
    assertEquals(cell10.getCard().get().getColor(), PlayerColor.RED);
  }

  @Test
  public void testAboveBattleTwoCellsTie() {
    cell4.aboveBattle(cell6, grid);
    assertEquals(cell4.getCard().get().getColor(), PlayerColor.RED);
    assertEquals(cell6.getCard().get().getColor(), PlayerColor.BLUE);
  }

  @Test
  public void testAboveBattleTwoHoles() {
    hole.aboveBattle(hole, grid);
    assertEquals(hole.getCard(), Optional.empty());
  }

  @Test
  public void testAboveBattleOneHoleOneCell() {
    cell1.aboveBattle(hole, grid);
    assertEquals(cell1.getCard(), card1);

  }

  //Below Battle
  @Test
  public void testBelowBattleTwoCells() {
    cell10.belowBattle(cell4, grid);
    assertEquals(cell10.getCard().get().getColor(), PlayerColor.BLUE);
    assertEquals(cell4.getCard().get().getColor(), PlayerColor.RED);

    cell4.belowBattle(cell10, grid);
    assertEquals(cell4.getCard().get().getColor(), PlayerColor.RED);
    assertEquals(cell10.getCard().get().getColor(), PlayerColor.RED);
  }

  @Test
  public void testBelowBattleTwoCellsTie() {
    cell6.belowBattle(cell4, grid);
    assertEquals(cell4.getCard().get().getColor(), PlayerColor.RED);
    assertEquals(cell6.getCard().get().getColor(), PlayerColor.BLUE);
  }

  @Test
  public void testBelowBattleTwoHoles() {
    hole.belowBattle(hole, grid);
    assertEquals(hole.getCard(), Optional.empty());
  }

  @Test
  public void testBelowBattleOneHoleOneCell() {
    cell1.belowBattle(hole, grid);
    assertEquals(cell1.getCard(), card1);
  }
}