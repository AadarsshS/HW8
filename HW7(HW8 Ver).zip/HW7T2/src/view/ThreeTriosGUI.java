package view;

import controller.ModelStatusListener;
import controller.PlayerActionListener;
import model.ThreeTriosModel;
import model.card.Card;
import model.cell.Hole;
import model.cell.ICell;
import model.player.AIPlayer;
import model.player.PlayerColor;
import model.ThreeTsModel;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.SwingConstants;
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import java.util.List;

/**
 * represents a ThreeTriosGUI.
 */
public class ThreeTriosGUI extends JFrame implements ThreeTsGUI {

  private final ThreeTsModel model;
  private JLabel currPlayerLabel;

  private JPanel playerPanel;

  private JButton[][] gridButtons;
  private Card selectedCard;

  private final List<PlayerActionListener> actionListeners = new ArrayList<>();

  /**
   * Constructor that makes the GUI for ThreeTrios.
   * @param model a ThreeTrios game model
   */
  public ThreeTriosGUI(ThreeTsModel model) {
    this.model = model;
    this.setTitle("Three Trios Game");
    this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    this.setLayout(new BorderLayout());

    initializeComponents();
    this.pack();
    this.setSize(800, 600);
    this.setVisible(true);
  }

  /**
   * Method that initializes the GUI components.
   */
  @Override
  public void initializeComponents() {
    currPlayerLabel = new JLabel("Current Player: RED", SwingConstants.CENTER);
    this.add(currPlayerLabel, BorderLayout.NORTH);

    JPanel gridPanel = new JPanel();
    int rows = model.getGrid().getNumRows();
    int cols = model.getGrid().getNumCols();
    gridPanel.setLayout(new GridLayout(rows, cols));
    gridButtons = new JButton[rows][cols];

    for (int row = 0; row < rows; row++) {
      for (int col = 0; col < cols; col++) {
        JButton button = new JButton();

        if (model.getGrid().getCell(row, col) instanceof Hole) {
          button.setBackground(Color.DARK_GRAY);
          button.setEnabled(false);
          button.setOpaque(true);
          button.setContentAreaFilled(false);
        } else {
          button.setBackground(Color.LIGHT_GRAY);
        }

        gridButtons[row][col] = button;
        gridPanel.add(button);

        int finalRow = row;
        int finalCol = col;
        button.addActionListener(new ActionListener() {
          @Override
          public void actionPerformed(ActionEvent e) {
            handleCellClick(finalRow, finalCol);
          }
        });
      }
    }
    this.add(gridPanel, BorderLayout.CENTER);

    playerPanel = new JPanel();
    playerPanel.setLayout(new GridLayout(1, 10));
    this.add(playerPanel, BorderLayout.SOUTH);

    JPanel leftPanel = new JPanel(new GridLayout(10, 1));
    leftPanel.setBackground(Color.PINK);
    for (Card card : model.getRed().getHand()) {
      JButton cardButton = new JButton(getCardDisplay(card));
      cardButton.addActionListener(new ActionListener() {
        @Override
        public void actionPerformed(ActionEvent e) {
          if (model.getCurrPlayer().getColor() == PlayerColor.RED) {
            selectedCard = card;
          } else {
            JOptionPane.showMessageDialog(
                    null,
                    "You cannot select cards from the opponent's hand.",
                    "Invalid Selection", JOptionPane.WARNING_MESSAGE);
          }
        }
      });
      leftPanel.add(cardButton);
    }
    this.add(leftPanel, BorderLayout.WEST);

    JPanel rightPanel = new JPanel(new GridLayout(10, 1));
    rightPanel.setBackground(Color.CYAN);
    for (Card card : model.getBlue().getHand()) {
      JButton cardButton = new JButton(getCardDisplay(card));
      cardButton.addActionListener(new ActionListener() {
        @Override
        public void actionPerformed(ActionEvent e) {
          if (model.getCurrPlayer().getColor() == PlayerColor.BLUE) {
            selectedCard = card;
          } else {
            JOptionPane.showMessageDialog(
                    null,
                    "You cannot select cards from the opponent's hand.",
                    "Invalid Selection", JOptionPane.WARNING_MESSAGE);
          }
        }
      });
      rightPanel.add(cardButton);
    }
    this.add(rightPanel, BorderLayout.EAST);

    model.addModelStatusListener(new ModelStatusListener() {
      @Override
      public void onChangedTurn(PlayerColor currentPlayer) {
        updateTurn(currentPlayer);
      }

      @Override
      public void onGameOver(model.player.Player winner, int winningScore) {
        showMessage("Winner: " + winner.getColor() + " with score " + winningScore,
                "Game Over");
      }
    });
  }


  /**
   * Method that handles clicking of a cell on the grid.
   * @param row the row index of the clicked cell.
   * @param col the column index of the clicked cell.
   */
  @Override
  public void handleCellClick(int row, int col) {
    if (selectedCard != null) {
      PlayerColor currentPlayerColor = model.getCurrPlayer().getColor();

      model.placeCard(row, col, selectedCard);
      gridButtons[row][col].setText(getCardDisplay(selectedCard));
      gridButtons[row][col].setBackground(
              currentPlayerColor == PlayerColor.RED ? Color.PINK : Color.CYAN);
      gridButtons[row][col].setOpaque(true);
      gridButtons[row][col].setContentAreaFilled(true);

      model.getCurrPlayer().getHand().remove(selectedCard);
      selectedCard = null;

      engageBattles(row, col);

      currPlayerLabel.setText("Current player: "
              +
              (model.getCurrPlayer().getColor() == PlayerColor.RED ? "RED" : "BLUE"));
      updateBoard();

      notifyCellSelect(row, col);
    } else {
      JOptionPane.showMessageDialog(
              this, "Select a card first.",
              "No card selected", JOptionPane.WARNING_MESSAGE);
    }
  }

  /**
   * Method that displays a card's attack values.
   * @param card the card to display.
   * @return string representation of card attack values.
   */
  @Override
  public String getCardDisplay(Card card) {
    return "<html><center>"
            + card.getNorth()
            + "<br>"
            + card.getWest()
            + " &nbsp;&nbsp; "
            + card.getEast()
            + "<br>"
            + card.getSouth()
            + "</center></html>";
  }

  /**
   * Method that updates the board by removing used card from hand and refreshing the display.
   */
  @Override
  public void updateBoard() {
    if (playerPanel == null) {
      System.err.println("playerPanel is not initialized.");
      return;
    }

    playerPanel.removeAll();

    for (Card card : model.getCurrPlayer().getHand()) {
      JButton cardButton = new JButton(getCardDisplay(card));
      cardButton.addActionListener(e -> {
        selectedCard = card;
        notifyCardSelect(card);
      });
      playerPanel.add(cardButton);
    }
    playerPanel.revalidate();
    playerPanel.repaint();
  }


  /**
   * Method that activates the battle methods of the game
   * and updates the board based on the outcome.
   * @param row the row index of the cell battling.
   * @param col the column index of the cell battling.
   */
  @Override
  public void engageBattles(int row, int col) {
    ICell cell = model.getGrid().getCell(row, col);

    performBattle(cell, row, col, row, col + 1);
    performBattle(cell, row, col, row, col - 1);
    performBattle(cell, row, col, row - 1, col);
    performBattle(cell, row, col, row + 1, col);

    PlayerColor newOwnerColor = cell.getCard().map(Card::getColor).orElse(null);
    if (newOwnerColor != null) {
      gridButtons[row][col].setBackground(
              newOwnerColor == PlayerColor.RED ? Color.PINK : Color.CYAN);
      gridButtons[row][col].setOpaque(true);
      gridButtons[row][col].setContentAreaFilled(true);
    }
  }

  private void notifyCardSelect(Card card) {
    for (PlayerActionListener listener : actionListeners) {
      listener.onCardSelect(card);
    }
  }

  private void notifyCellSelect(int row, int col) {
    for (PlayerActionListener listener : actionListeners) {
      listener.onCellSelect(row, col);
    }
  }

  @Override
  public void addPlayerActionListener(PlayerActionListener listener) {
    actionListeners.add(listener);
  }

  @Override
  public void updateTurn(PlayerColor currentPlayer) {
    currPlayerLabel.setText("Current Player: " + currentPlayer);

    if (model.getCurrPlayer() instanceof AIPlayer) {
      AIPlayer aiPlayer = (AIPlayer) model.getCurrPlayer();
      aiPlayer.playTurn((ThreeTriosModel) model);
      updateTurn(model.getCurrPlayer().getColor());
    }
  }

  @Override
  public void showMessage(String message, String title) {
    JOptionPane.showMessageDialog(
            this, message, title, JOptionPane.INFORMATION_MESSAGE);
  }

  @Override
  public void selectCard(Card card) {
    this.selectedCard = card;
  }

  @Override
  public Card getSelectedCard() {
    return selectedCard;
  }


  /**
   * Helper method to perform a battle between two cells
   * and update the GUI color if ownership changes.
   * @param initialCell the cell from which the battle is initiated.
   * @param initRow the row index of the initial cell.
   * @param initCol the column index of the initial cell.
   * @param targRow the row index of the target cell.
   * @param targCol the column index of the target cell.
   *
   */
  private void performBattle(
          ICell initialCell, int initRow, int initCol, int targRow, int targCol) {
    if (targRow >= 0 && targRow < model.getGrid().getNumRows()
            && targCol >= 0 && targCol < model.getGrid().getNumCols()) {

      ICell targetCell = model.getGrid().getCell(targRow, targCol);
      PlayerColor originalColor = targetCell.getCard().map(Card::getColor).orElse(null);

      if (initRow == targRow && initCol + 1 == targCol) {
        initialCell.rightBattle(targetCell, model.getGrid());
      } else if (initRow == targRow && initCol - 1 == targCol) {
        initialCell.leftBattle(targetCell, model.getGrid());
      } else if (initRow - 1 == targRow && initCol == targCol) {
        initialCell.aboveBattle(targetCell, model.getGrid());
      } else if (initRow + 1 == targRow && initCol == targCol) {
        initialCell.belowBattle(targetCell, model.getGrid());
      }

      PlayerColor newColor = targetCell.getCard().map(Card::getColor).orElse(null);
      if (originalColor != newColor && model.getCurrPlayer().getColor() == newColor) {
        gridButtons[targRow][targCol].setBackground(
                newColor == PlayerColor.RED ? Color.PINK : Color.CYAN);
        gridButtons[targRow][targCol].setOpaque(true);
        gridButtons[targRow][targCol].setContentAreaFilled(true);

        engageBattles(targRow, targCol);
      }
    }
  }
}
