package view;

import java.io.FileNotFoundException;

import controller.ThreeTriosController;
import model.ThreeTriosModel;
import model.ThreeTsModel;
import model.player.AIPlayer;
import model.player.Player;
import model.player.PlayerColor;
import model.strategies.Corner;
import model.strategies.MostFlips;
import model.strategies.Strategy;

/**
 * Main class for launching the Three Trios game.
 * Sets up and initializes model, view, and GUI.
 */
public final class ThreeTrios {

  /**
   * Main method that launches the Three Trios game.
   *
   * @param args command-line arguments
   * @throws FileNotFoundException if the specified files are not found
   */
  public static void main(String[] args) throws FileNotFoundException {
    ThreeTsModel model = new ThreeTriosModel("path/to/card/file", "path/to/grid/file");

    Strategy cornerStrategy = new Corner(model);
    Strategy mostFlipsStrategy = new MostFlips();


    Player player1 = model.getRed();
    Player player2 = new AIPlayer(PlayerColor.BLUE, model, new Corner(model));

    ThreeTriosGUI view1 = new ThreeTriosGUI(model);
    ThreeTriosGUI view2 = new ThreeTriosGUI(model);

    ThreeTriosController controller1 = new ThreeTriosController(model, player1, view1);
    ThreeTriosController controller2 = new ThreeTriosController(model, player2, view2);

    model.startGame();

    if (model.getCurrPlayer().equals(player2)) {
      ((AIPlayer) player2).playTurn((ThreeTriosModel) model);
    }
  }
}
