package view;

/**
 * Represents the game view of the ThreeTrios Game.
 */
public interface ThreeTsView {

  /**
   * Reprsents a string view of the game ThreeTrios.
   *
   * @return the string view of the game.
   */
  @Override
  String toString();

}
