package view;

import controller.PlayerActionListener;
import model.card.Card;
import model.player.PlayerColor;

/**
 * Interface that represents the GUI or Graphical User Interface of the ThreeTrios Game.
 */
public interface ThreeTsGUI {

  /**
   * Initializes the GUI components.
   */
  void initializeComponents();

  /**
   * Handles the action when a cell on the grid is clicked.
   * @param row the row index of the clicked cell.
   * @param col the column index of the clicked cell.
   */
  void handleCellClick(int row, int col);

  /**
   * Generates the display string for a card's attack values.
   * @param card the card to display.
   * @return the string representation of the card's attack values.
   */
  String getCardDisplay(Card card);

  /**
   * Updates the board by removing used card from hand and refreshing the display.
   */
  void updateBoard();

  /**
   * Activate the battle methods of the game and updates the board based on the outcome.
   * @param row the row index of the cell battling.
   * @param col the column index of the cell battling.
   */
  void engageBattles(int row, int col);

  void addPlayerActionListener(PlayerActionListener listener);

  void updateTurn(PlayerColor currentPlayer);

  void showMessage(String message, String gameOver);

  void selectCard(Card card);

  Card getSelectedCard();
}
