package view;

import model.card.Card;
import model.grid.IGrid;
import model.player.PlayerColor;
import model.ThreeTsModel;

import java.util.Optional;

/**
 * Represents the game view of the ThreeTrios Game.
 */
public class ThreeTriosView implements ThreeTsView {

  private final ThreeTsModel model;

  /**
   * constructor for the ThreeTsView.
   *
   * @param model represents the model.
   */
  public ThreeTriosView(ThreeTsModel model) {
    //Exceptions
    if (model == null) {
      throw new IllegalArgumentException("Model is null!");
    }

    this.model = model;
  }

  /**
   * Represents string view of the ThreeTriosGame.
   *
   * @return the string view of the game.
   */
  @Override
  public String toString() {
    StringBuilder view = new StringBuilder();

    view.append("Player: ")
            .append(model.getCurrPlayer().getIfCurrPlayer() ? "RED" : "BLUE").append("\n");

    IGrid grid = model.getGrid();
    int rows = grid.getNumRows();
    int cols = grid.getNumCols();

    for (int row = 0; row < rows; row++) {
      for (int col = 0; col < cols; col++) {
        Optional<Card> card = grid.getCell(row, col).getCard();
        if (card.isPresent()) {
          view.append(card.get().getColor() == PlayerColor.RED ? "R" : "B");
        } else {
          view.append("_");
        }
        view.append(" ");
      }
      view.append("\n");
    }

    view.append("Hand:\n");
    for (Card card : model.getCurrPlayer().getHand()) {
      view.append(card.getCardName()).append(" ").append(card.getNorth()).append(" ")
              .append(card.getSouth()).append(" ")
              .append(card.getEast()).append(" ")
              .append(card.getWest()).append(" ")
              .append("\n");
    }

    return view.toString();
  }
}

