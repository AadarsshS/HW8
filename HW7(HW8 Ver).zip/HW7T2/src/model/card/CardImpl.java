package model.card;

import java.util.Objects;

import model.player.PlayerColor;

import static model.player.PlayerColor.BLUE;
import static model.player.PlayerColor.RED;

/**
 * represents a Card in the ThreeTriosGame.
 */
public class CardImpl implements Card {

  String name;

  int north;
  int south;
  int east;
  int west;
  PlayerColor color;

  /**
   * constructor for CardImpl.
   *
   * @param name represents the name of the card.
   * @param north represents the north value of the card.
   * @param south represents the south value of the card.
   * @param east represents the east value of the card.
   * @param west represents the west value of the card.
   * @param color represents the colo value of the card.
   */
  public CardImpl(String name, int north, int south, int east, int west, PlayerColor color) {
    //Exceptions
    if (north < 1 || north > 10) {
      throw new IllegalArgumentException("Invalid north value!");
    }
    if (south < 1 || south > 10) {
      throw new IllegalArgumentException("Invalid south value!");
    }
    if (east < 1 || east > 10) {
      throw new IllegalArgumentException("Invalid east value!");
    }
    if (west < 1 || west > 10) {
      throw new IllegalArgumentException("Invalid west value!");
    }

    if (color == null) {
      throw new IllegalArgumentException("Color is null!");
    }
    if (name == null) {
      throw new IllegalArgumentException("Name is null!");
    }

    //setting values
    this.name = name;

    this.north = north;
    this.south = south;
    this.east = east;
    this.west = west;

    this.color = color;
  }

  @Override
  public void switchOwnership() {
    if (this.color == RED) {
      this.color = BLUE;
    } else if (this.color == BLUE) {
      this.color = PlayerColor.RED;
    }
  }

  @Override
  public int getNorth() {
    return this.north;
  }

  @Override
  public int getSouth() {
    return this.south;
  }

  @Override
  public int getEast() {
    return this.east;
  }

  @Override
  public int getWest() {
    return this.west;
  }

  @Override
  public PlayerColor getColor() {
    return this.color;
  }

  @Override
  public void setColor(PlayerColor color) {
    this.color = color;
  }

  @Override
  public String getCardName() {
    return this.name;
  }

  @Override
  public boolean equals(Object obj) {
    if (this == obj) {
      return true; // If both references are identical, they are equal
    }
    if (obj == null || getClass() != obj.getClass()) {
      return false; // Return false if the object is null or a different class
    }
    CardImpl card = (CardImpl) obj; // Cast obj to CardImpl to access fields
    // Compare all fields for equality
    return north == card.north
            && south == card.south
            && east == card.east
            && west == card.west
            && color == card.color
            && Objects.equals(name, card.name);
  }

  @Override
  public int hashCode() {
    return Objects.hash(name, north, south, east, west, color);
  }
}
