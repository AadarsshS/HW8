package model.card;

import model.player.PlayerColor;

/**
 * Represents a card used in Three Trios Game.
 */
public interface Card {

  /**
   * Method that switches the ownership of a card from one player to the other.
   */
  void switchOwnership();

  /**
   * Gets the north value of a card.
   *
   * @return the north value of the card.
   */
  int getNorth();

  /**
   * Gets the south value of a card.
   *
   * @return the south value of the card.
   */
  int getSouth();

  /**
   * Gets the east value of a card.
   *
   * @return the east value of the card.
   */
  int getEast();

  /**
   * Gets the west value of a card.
   *
   * @return the west value of the card.
   */
  int getWest();

  /**
   * Gets the color value of a card.
   *
   * @return the color value of the card.
   */
  PlayerColor getColor();

  /**
   * sets the color value of a card.
   */
  void setColor(PlayerColor color);

  /**
   * Gets the name of a card.
   *
   * @return the name value of the card.
   */
  String getCardName();

  /**
   * equals method for a Card.
   */

  boolean equals(Object obj);

  /**
   * hashcode for a Card.
   */

  int hashCode();
}
