package model.cell;

import java.util.Optional;

import model.grid.IGrid;
import model.player.PlayerColor;
import model.card.Card;

/**
 * Represents a cell on ThreeTrios Game grid.
 */
public class Cell implements ICell {

  private Optional<Card> card;

  /**
   * constructor for a Cell.
   *
   * @param card represents the card in a cell.
   */
  public Cell(Optional<Card> card) {
    //Exception
    if (card == null) {
      throw new IllegalArgumentException("Card is null!");
    }

    this.card = card;
  }

  @Override
  public Optional<Card> getCard() {
    return this.card;
  }

  @Override
  public void setCard(Optional<Card> card) {
    this.card = card;
  }


  @Override
  public void rightBattle(ICell otherCell, IGrid grid) {
    final int[] num1 = new int[1];
    final int[] num2 = new int[1];

    final PlayerColor[] color1 = new PlayerColor[1];
    final PlayerColor[] color2 = new PlayerColor[1];

    this.card.ifPresent(card1 -> num1[0] = card1.getEast());
    this.card.ifPresent(card1 -> color1[0] = card1.getColor());

    otherCell.getCard().ifPresent(card2 -> num2[0] = card2.getWest());
    otherCell.getCard().ifPresent(card2 -> color2[0] = card2.getColor());

    if ((num1[0] > num2[0]) && (color1[0] != color2[0])) {
      otherCell.getCard().ifPresent(card -> {
        card.switchOwnership();
        otherCell.setCard(Optional.of(card));
      });

      grid.cellBattle(otherCell);
    }
  }

  @Override
  public void leftBattle(ICell otherCell, IGrid grid) {
    final int[] num1 = new int[1];
    final int[] num2 = new int[1];

    final PlayerColor[] color1 = new PlayerColor[1];
    final PlayerColor[] color2 = new PlayerColor[1];

    this.card.ifPresent(card1 -> num1[0] = card1.getWest());
    this.card.ifPresent(card1 -> color1[0] = card1.getColor());

    otherCell.getCard().ifPresent(card2 -> num2[0] = card2.getEast());
    otherCell.getCard().ifPresent(card2 -> color2[0] = card2.getColor());

    if ((num1[0] > num2[0]) && (color1[0] != color2[0])) {
      otherCell.getCard().ifPresent(card -> {
        card.switchOwnership();
        otherCell.setCard(Optional.of(card));
      });

      grid.cellBattle(otherCell);
    }
  }

  @Override
  public void aboveBattle(ICell otherCell, IGrid grid) {
    final int[] num1 = new int[1];
    final int[] num2 = new int[1];

    final PlayerColor[] color1 = new PlayerColor[1];
    final PlayerColor[] color2 = new PlayerColor[1];

    this.card.ifPresent(card1 -> num1[0] = card1.getNorth());
    this.card.ifPresent(card1 -> color1[0] = card1.getColor());

    otherCell.getCard().ifPresent(card2 -> num2[0] = card2.getSouth());
    otherCell.getCard().ifPresent(card2 -> color2[0] = card2.getColor());

    if ((num1[0] > num2[0]) && (color1[0] != color2[0])) {
      otherCell.getCard().ifPresent(card -> {
        card.switchOwnership();
        otherCell.setCard(Optional.of(card));
      });

      grid.cellBattle(otherCell);
    }
  }

  @Override
  public void belowBattle(ICell otherCell, IGrid grid) {
    final int[] num1 = new int[1];
    final int[] num2 = new int[1];

    final PlayerColor[] color1 = new PlayerColor[1];
    final PlayerColor[] color2 = new PlayerColor[1];

    this.card.ifPresent(card1 -> num1[0] = card1.getSouth());
    this.card.ifPresent(card1 -> color1[0] = card1.getColor());

    otherCell.getCard().ifPresent(card2 -> num2[0] = card2.getNorth());
    otherCell.getCard().ifPresent(card2 -> color2[0] = card2.getColor());

    if ((num1[0] > num2[0]) && (color1[0] != color2[0])) {
      otherCell.getCard().ifPresent(card -> {
        card.switchOwnership();
        otherCell.setCard(Optional.of(card));
      });

      grid.cellBattle(otherCell);
    }
  }
}
