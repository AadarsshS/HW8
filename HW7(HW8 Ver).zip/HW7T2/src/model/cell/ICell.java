package model.cell;

import java.util.Optional;

import model.grid.IGrid;
import model.card.Card;

/**
 * Represents a cell on the ThreeTrios Game grid.
 */
public interface ICell {
  /**
   * Get's a cell's card.
   */
  Optional<Card> getCard();

  /**
   * Sets a cell's card.
   *
   * @param card represents the card the cell's card will be set to.
   */
  void setCard(Optional<Card> card);

  /**
   * Performs the cell battle between a given cell the cell on it's right.
   *
   * @param otherCell is the cell on the right.
   * @param grid      is the grid the cells are on.
   */
  void rightBattle(ICell otherCell, IGrid grid);

  /**
   * Performs the cell battle between a given cell the cell on it's left.
   *
   * @param otherCell is the cell on the left.
   * @param grid      is the grid the cells are on.
   */
  void leftBattle(ICell otherCell, IGrid grid);

  /**
   * Performs the cell battle between a given cell the cell above it.
   *
   * @param otherCell is the cell above it.
   * @param grid      is the grid the cells are on.
   */
  void aboveBattle(ICell otherCell, IGrid grid);

  /**
   * Performs the cell battle between a given cell the cell below it.
   *
   * @param otherCell is the cell below it.
   * @param grid      is the grid the cells are on.
   */
  void belowBattle(ICell otherCell, IGrid grid);

}
