package model.cell;

import java.util.Optional;

import model.grid.IGrid;
import model.card.Card;

/**
 * Represents a hole in the grid.
 */
public class Hole implements ICell {
  @Override
  public Optional<Card> getCard() {
    return Optional.empty();
  }

  @Override
  public void setCard(Optional<Card> card) {
    //This method is not needed in hole.

  }

  @Override
  public void rightBattle(ICell otherCell, IGrid grid) {
    //This method is not needed in hole.

  }

  @Override
  public void leftBattle(ICell otherCell, IGrid grid) {
    //This method is not needed in hole.

  }

  @Override
  public void aboveBattle(ICell otherCell, IGrid grid) {
    //This method is not needed in hole.

  }

  @Override
  public void belowBattle(ICell otherCell, IGrid grid) {
    //This method is not needed in hole.

  }
}
