package model;

import java.util.ArrayList;
import java.util.List;

import static model.player.PlayerColor.BLUE;
import static model.player.PlayerColor.RED;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.Optional;
import java.util.Scanner;
import controller.ModelStatusListener;
import model.card.Card;
import model.card.CardImpl;
import model.cell.Cell;
import model.cell.Hole;
import model.cell.ICell;
import model.grid.Grid;
import model.grid.IGrid;
import model.player.AIPlayer;
import model.player.MainPlayer;
import model.player.Player;
import model.player.PlayerColor;

/**
 * Represents a Three Trios Game Model.
 */
public class ThreeTriosModel implements ThreeTsModel {


  // instance variables for the three trios model
  int rows;
  int cols;
  List<ICell> gridCells = new ArrayList<ICell>();
  private Player red = new MainPlayer(RED, new ArrayList<Card>(), true, 0);
  private Player blue = new MainPlayer(BLUE, new ArrayList<Card>(), false, 0);
  List<Card> deck = new ArrayList<Card>();
  IGrid grid;

  private final List<ModelStatusListener> listeners = new ArrayList<>();

  @Override
  public void gridFileReader(String fileName) throws FileNotFoundException {
    try {
      File myObj = new File(fileName);
      Scanner myReader = new Scanner(myObj);
      rows = myReader.nextInt();
      cols = myReader.nextInt();
      while (myReader.hasNextLine()) {
        String gridRow = myReader.next();
        for (int i = 0; i < gridRow.length(); i++) {
          if (gridRow.charAt(i) == 'X') {
            gridCells.add(new Hole());
          }
          if (gridRow.charAt(i) == 'C') {
            gridCells.add(new Cell(Optional.empty()));
          }
        }
      }
      myReader.close();
    } catch (FileNotFoundException e) {
      throw new FileNotFoundException("File not found");
    }
    grid = new Grid(rows, cols, gridCells);
  }

  @Override
  public void cardFileReader(String fileName) throws FileNotFoundException {
    deck.clear();
    try {
      File myObj = new File(fileName);
      Scanner myReader = new Scanner(myObj);
      while (myReader.hasNextLine()) {
        String cardName = myReader.next();
        int north = myReader.nextInt();
        int south = myReader.nextInt();
        int east = myReader.nextInt();
        int west = myReader.nextInt();
        deck.add(new CardImpl(cardName, north, south, east, west, PlayerColor.RED));
      }
      myReader.close();
    } catch (FileNotFoundException e) {
      throw new FileNotFoundException("File not found");
    }
  }

  /**
   * Constructor for a ThreeTriosModel.
   *
   * @param deck represents the deck.
   * @param grid represents the grid.
   * @param red  represents the red player.
   * @param blue represents the blue player.
   */
  public ThreeTriosModel(List<Card> deck, IGrid grid, Player red, Player blue) {
    //Exceptions
    int numHoles = 0;
    for (int i = 0; i < gridCells.size(); i++) {
      if (gridCells.get(i) instanceof Hole) {
        numHoles++;
      }
    }
    if (deck.size() < gridCells.size() - numHoles) {
      throw new IllegalStateException("Not enough cards for the grid!");
    }
    if (deck.isEmpty()) {
      throw new IllegalStateException("Deck should not be empty!");
    }

    //Implementation
    this.grid = grid;
    this.gridCells = this.grid.getGridCells();
    this.deck = new ArrayList<>(deck);
    this.red = red;
    this.blue = blue;

    dealDeck();

    red.setScore(red.getHand().size() + grid.getNumRed());
    blue.setScore(blue.getHand().size() + grid.getNumBlue());
  }

  /**
   * An extra constructor for ThreeTriosModel that takes in a cardFile or gridFileReader.
   * @param cardFileReader that takes in a cardFileReader
   * @param gridFileReader that takes in a gridFileReader
   * @throws FileNotFoundException if there is no file to reference
   */
  public ThreeTriosModel(String cardFileReader, String gridFileReader)
          throws FileNotFoundException {
    this.cardFileReader(cardFileReader);
    this.gridFileReader(gridFileReader);

    //Exceptions
    int numHoles = 0;
    for (int i = 0; i < gridCells.size(); i++) {
      if (gridCells.get(i) instanceof Hole) {
        numHoles++;
      }
    }
    if (deck.size() < gridCells.size() - numHoles) {
      throw new IllegalStateException("Not enough cards for the grid!");
    }
    if (deck.isEmpty()) {
      throw new IllegalStateException("Deck should not be empty!");
    }

    //Implementation

    this.deck = new ArrayList<>(deck);

    dealDeck();

    red.setScore(red.getHand().size() + grid.getNumRed());
    blue.setScore(blue.getHand().size() + grid.getNumBlue());
  }

  @Override
  public void startGame() {
    if (grid == null || gridCells.isEmpty()) {
      throw new IllegalStateException("Grid is not initialized!");
    }
    if (deck.isEmpty()) {
      throw new IllegalStateException("Deck is not initialized!");
    }

    red.setIfCurrPlayer(true);
    blue.setIfCurrPlayer(false);

    if (red.getHand().isEmpty() && blue.getHand().isEmpty()) {
      dealDeck();
    }

    red.setScore(red.getHand().size() + grid.getNumRed());
    blue.setScore(blue.getHand().size() + grid.getNumBlue());

    notifyTurnListeners();
  }

  private void notifyTurnListeners() {
    if (listeners != null) {
      for (ModelStatusListener listener : listeners) {
        listener.onChangedTurn(getCurrPlayer().getColor());
      }
    }
  }

  @Override
  public void dealDeck() {
    //Exceptions
    if (deck.isEmpty()) {
      throw new IllegalStateException("Deck is empty!");
    }

    //Implementation
    for (Card c : deck) {
      if ((deck.indexOf(c) % 2) == 0) {
        red.getHand().add(deck.get(deck.indexOf(c)));
      } else if ((deck.indexOf(c) % 2) == 1) {
        c.switchOwnership();
        blue.getHand().add((deck.get(deck.indexOf(c))));
      }
    }

    for (Card c : red.getHand()) {
      c.setColor(RED);
    }
    for (Card c : blue.getHand()) {
      c.setColor(BLUE);
    }
  }

  @Override
  public void placeCard(int row, int col, Card card) {
    //Exceptions
    if (row < 0 || row > getGrid().getNumRows() - 1) {
      throw new IllegalArgumentException("Invalid num of rows!");
    }
    if (col < 0 || col > getGrid().getNumCols() - 1) {
      throw new IllegalArgumentException("Invalid num of columns!");
    }
    if (card == null) {
      throw new IllegalArgumentException("Invalid card input");
    }
    if (isGameOver()) {
      throw new IllegalStateException("Game is over!");
    }
    if (isGameWon()) {
      throw new IllegalStateException("Game is won!");
    }
    if (!card.getColor().equals(getCurrPlayer().getColor())) {
      throw new IllegalArgumentException("Not your turn!");
    }

    //Implementation
    Player currPlayer = this.getCurrPlayer();
    List<Card> hand = new ArrayList<Card>(currPlayer.getHand());
    hand.remove(card);

    if (card.getColor().equals(PlayerColor.RED)) {
      this.red.setHand(hand);
    } else if (card.getColor().equals(PlayerColor.BLUE)) {
      this.blue.setHand(hand);
    }

    grid.placeCard(row, col, card);
    switchCurrPlayer();

    this.red.setScore(grid.getNumRed() + red.getHand().size());
    this.blue.setScore(grid.getNumBlue() + blue.getHand().size());
  }

  @Override
  public boolean isGameWon() {
    //Exceptions

    //Implementation
    int cellsFullCount = 0;
    for (int rowPosition = 0; rowPosition < grid.getNumRows() - 1; rowPosition++) {
      for (int colPosition = 0; colPosition < grid.getNumCols() - 1; colPosition++) {
        if (grid.getCell(rowPosition, colPosition) instanceof Hole
                || grid.getCell(rowPosition, colPosition).getCard().isPresent()) {
          cellsFullCount++;
        }
      }
    }

    return cellsFullCount == (grid.getNumRows() * grid.getNumCols()) - 1;
  }

  @Override
  public boolean isGameOver() {
    boolean gameWon = isGameWon();
    boolean redHandEmpty = red.getHand().isEmpty();
    boolean blueHandEmpty = blue.getHand().isEmpty();

    if (gameWon || redHandEmpty || blueHandEmpty) {
      notifyGameOverListeners();
      logGameOverReason(gameWon, redHandEmpty, blueHandEmpty);
    }

    return gameWon || redHandEmpty || blueHandEmpty;
  }

  private void logGameOverReason(boolean gameWon, boolean redHandEmpty, boolean blueHandEmpty) {
    if (gameWon) {
      System.out.println("Game ended because someone won.");
    } else if (redHandEmpty || blueHandEmpty) {
      System.out.println("Game ended because a player's hand is empty.");
    }
  }

  private void notifyGameOverListeners() {
    if (listeners != null) {
      for (ModelStatusListener listener : listeners) {
        model.player.Player winner = (Player) determineWinner();
        int winningScore = winner != null ? winner.getScore() : -1;
        listener.onGameOver(winner, winningScore);
      }
    }
  }

  private Object determineWinner() {
    if (red.getScore() > blue.getScore()) {
      return PlayerColor.RED;
    } else if (blue.getScore() > red.getScore()) {
      return PlayerColor.BLUE;
    } else {
      return null;
    }
  }

  @Override
  public Player getCurrPlayer() {
    if (red.getIfCurrPlayer()) {
      return red;
    }
    return blue;
  }

  @Override
  public void switchCurrPlayer() {
    this.red.setIfCurrPlayer(!red.getIfCurrPlayer());
    this.blue.setIfCurrPlayer(!blue.getIfCurrPlayer());
    Player currentPlayer = getCurrPlayer();
    if (currentPlayer instanceof AIPlayer) {
      ((AIPlayer) currentPlayer).playTurn(this);
    }
    notifyChangedTurn(getCurrPlayer().getColor());
  }

  private void notifyChangedTurn(PlayerColor color) {
    for (ModelStatusListener listener : listeners) {
      listener.onChangedTurn(getCurrPlayer().getColor());
    }
  }

  @Override
  public IGrid getGrid() {
    return this.grid;
  }

  @Override
  public Player getRed() {
    return this.red;
  }

  @Override
  public Player getBlue() {
    return this.blue;
  }

  /**
   * Method that sets the players.
   *
   * @param red The Red Player
   * @param blue The Blue Player
   */
  public void setPlayers(Player red, Player blue) {
    if (red == null || blue == null) {
      throw new IllegalArgumentException("Players cannot be null.");
    }
    this.red = red;
    this.blue = blue;
  }

  @Override
  public int numCardsCanFlip(Card card, int row, int col) {

    //Exceptions
    if (row < 0 || row > getGrid().getNumRows()) {
      throw new IllegalStateException("Invalid Row!");
    }
    if (col < 0 || col > getGrid().getNumCols()) {
      throw new IllegalStateException("Invalid Col!");
    }
    if (card == null) {
      throw new IllegalStateException("Invalid Card!");
    }
    if (isGameOver()) {
      throw new IllegalStateException("Game is over!");
    }
    if (isGameWon()) {
      throw new IllegalStateException("Game is won!");
    }
    if (getGrid().getCell(row, col) instanceof Hole) {
      return 0;
    }
    if (getGrid().getCell(row, col).getCard().isPresent()) {
      return 0;
    }

    List<ICell> gridCellsMock = new ArrayList<ICell>(gridCells);
    System.out.println(gridCellsMock.get(4).getCard().get().getCardName());
    IGrid gridMock = new Grid(this.grid.getNumRows(), this.grid.getNumCols(), gridCellsMock);

    //Implementation
    int original = 0;
    if (red.getIfCurrPlayer()) {
      System.out.println("original red: " + gridMock.getNumRed());
      System.out.println("original blue: " + gridMock.getNumBlue());
      original = gridMock.getNumRed();
    } else if (blue.getIfCurrPlayer()) {
      original = gridMock.getNumBlue();
    }

    gridMock.placeCard(row, col, card);
    gridMock.cellBattle(gridMock.getCell(row, col));

    int numFlipped = 0;
    if (red.getIfCurrPlayer()) {
      System.out.println("red: " + gridMock.getNumRed());
      System.out.println("blue: " + gridMock.getNumBlue());
      numFlipped = original - gridMock.getNumRed();
    } else if (blue.getIfCurrPlayer()) {
      System.out.println("blue: " + gridMock.getNumBlue());
      numFlipped = original - gridMock.getNumBlue();
    }

    return numFlipped;
  }

  //strategic methods

  /**
   * finds the best card from a player's hand to place on the top left corner.
   *
   * @param hand the given cards in a hand.
   * @return the index in the hand that is best for the top left.
   */
  private int findBestForTopLeft(List<Card> hand) {
    int max = -1;
    int maxIndex = 0;
    for (int cardIndex = 0; cardIndex < hand.size(); cardIndex++) {
      if ((hand.get(cardIndex).getEast() + hand.get(cardIndex).getSouth()) > max) {
        maxIndex = cardIndex;
        max = hand.get(cardIndex).getEast() + hand.get(cardIndex).getSouth();
      }
    }
    return maxIndex;
  }

  /**
   * finds the best card from a player's hand to place on top right corner.
   *
   * @param hand the given cards in a hand.
   * @return the index in the hand that is best for the top right.
   */
  private int findBestForTopRight(List<Card> hand) {
    int max = -1;
    int maxIndex = 0;
    for (int cardIndex = 0; cardIndex < hand.size(); cardIndex++) {
      if ((hand.get(cardIndex).getWest() + hand.get(cardIndex).getSouth()) > max) {
        maxIndex = cardIndex;
        max = hand.get(cardIndex).getWest() + hand.get(cardIndex).getSouth();
      }
    }
    return maxIndex;
  }

  /**
   * finds the best card from a player's hand to place on bottom left corner.
   *
   * @param hand the given cards in a hand.
   * @return the index in the hand that is best for the bottom left.
   */
  private int findBestForBottomLeft(List<Card> hand) {
    int max = -1;
    int maxIndex = 0;
    for (int cardIndex = 0; cardIndex < hand.size(); cardIndex++) {
      if ((hand.get(cardIndex).getEast() + hand.get(cardIndex).getNorth()) > max) {
        maxIndex = cardIndex;
        max = hand.get(cardIndex).getEast() + hand.get(cardIndex).getNorth();
      }
    }
    return maxIndex;
  }

  /**
   * finds the best card from a player's hand to place on bottom right corner.
   *
   * @param hand the given cards in a hand.
   * @return the index in the hand that is best for the bottom right.
   */
  private int findBestForBottomRight(List<Card> hand) {
    int max = -1;
    int maxIndex = 0;
    for (int cardIndex = 0; cardIndex < hand.size(); cardIndex++) {
      if ((hand.get(cardIndex).getWest() + hand.get(cardIndex).getSouth()) > max) {
        maxIndex = cardIndex;
        max = hand.get(cardIndex).getEast() + hand.get(cardIndex).getSouth();
      }
    }
    return maxIndex;
  }

  @Override
  public void cornerPlay() {
    Player player = getCurrPlayer();

    if (!(this.getGrid().getCell(0, 0) instanceof Hole)
            && this.getGrid().getCell(0, 0).getCard().isEmpty()) {
      this.placeCard(0, 0,
              player.getHand().get(findBestForTopLeft(player.getHand())));
    } else if (!(this.getGrid().getCell(0, this.getGrid().getNumCols() - 1) instanceof Hole)
            && this.getGrid().getCell(0, this.getGrid().getNumCols() - 1).getCard().isEmpty()) {
      this.placeCard(0, this.getGrid().getNumCols() - 1,
              player.getHand().get(findBestForTopRight(player.getHand())));
    } else if (!(this.getGrid().getCell(this.getGrid().getNumRows() - 1, 0) instanceof Hole)
            && this.getGrid().getCell(this.getGrid().getNumRows() - 1, 0).getCard().isEmpty()) {
      this.placeCard(this.getGrid().getNumRows() - 1, 0,
              player.getHand().get(findBestForBottomLeft(player.getHand())));
    } else if (!(this.getGrid().getCell(this.getGrid().getNumRows() - 1,
            this.getGrid().getNumCols() - 1) instanceof Hole)
            && this.getGrid().getCell(this.getGrid().getNumRows() - 1,
            this.getGrid().getNumCols() - 1).getCard().isEmpty()) {
      this.placeCard(this.getGrid().getNumRows() - 1, this.getGrid().getNumCols() - 1,
              player.getHand().get(findBestForBottomRight(player.getHand())));
    }
  }

  @Override
  public void flipPlay() {
    Player player = getCurrPlayer();
    int maxFlips = -1;
    List<Card> maxCardsList = new ArrayList<Card>();

    //finding the cards that can make the max flips
    for (int cardIndex = 0; cardIndex < player.getHand().size(); cardIndex++) {
      if (maxFlips(player.getHand().get(cardIndex)) > maxFlips) {
        maxCardsList.clear();
        maxFlips = maxFlips(player.getHand().get(cardIndex));
        maxCardsList.add(player.getHand().get(cardIndex));
      } else if (maxFlips(player.getHand().get(cardIndex)) == maxFlips) {
        maxCardsList.add(player.getHand().get(cardIndex));
      }
    }

    //if there is a tie using the card that had the lowest index in the grid list
    if (maxCardsList.size() == 1) {
      Card card = maxCardsList.get(0);
      int row = maxFlipsRow(card);
      int col = maxFlipsCol(card);
      this.placeCard(row, col, card);
    } else {
      int minIndex = (int) Double.POSITIVE_INFINITY;
      int minIndexInMaxCardList = -1;

      for (int cardIndex = 0; cardIndex < maxCardsList.size(); cardIndex++) {
        Card currCard = maxCardsList.get(cardIndex);
        if (this.cols * (maxFlipsRow(currCard) - 1) + maxFlipsCol(currCard) < minIndex) {
          minIndex = this.cols * (maxFlipsRow(currCard) - 1) + maxFlipsCol(currCard);
          minIndexInMaxCardList = cardIndex;
        }
      }

      Card finalCard = maxCardsList.get(minIndexInMaxCardList);
      this.placeCard(maxFlipsRow(finalCard), maxFlipsCol(finalCard), finalCard);
    }
  }

  /**
   * Adds the model status listener.
   *
   * @param listener that is added
   */
  @Override
  public void addModelStatusListener(ModelStatusListener listener) {
    listeners.add(listener);
  }


  /**
   * used to find the max amount of flips a given card can do on the grid.
   *
   * @return the max amount of flips.
   */
  private int maxFlips(Card card) {
    int max = 0;
    for (int row = 0; row < this.grid.getNumRows(); row++) {
      for (int col = 0; col < this.grid.getNumCols(); col++) {
        if (this.numCardsCanFlip(card, row, col) > max) {
          max = this.numCardsCanFlip(card, row, col);
        }
      }
    }
    System.out.println("max: " + max);
    return max;
  }

  /**
   * used to determine the first point in which a card will flip the max number of cards on the
   * grid.
   *
   * @return the row.
   */
  private int maxFlipsRow(Card card) {
    int max = maxFlips(card);
    for (int row = 0; row < this.grid.getNumRows(); row++) {
      for (int col = 0; col < this.grid.getNumCols(); col++) {
        if (this.numCardsCanFlip(card, row, col) == max) {
          return row;
        }
      }
    }
    return -1;
  }

  /**
   * used to determine the first point in which a card will flip the max number of cards on the
   * grid.
   *
   * @return the col.
   */
  private int maxFlipsCol(Card card) {
    int max = maxFlips(card);
    for (int row = 0; row < this.grid.getNumRows(); row++) {
      for (int col = 0; col < this.grid.getNumCols(); col++) {
        if (this.numCardsCanFlip(card, row, col) == max) {
          return col;
        }
      }
    }
    return -1;
  }
}
