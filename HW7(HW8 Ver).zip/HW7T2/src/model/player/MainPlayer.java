package model.player;

import java.util.ArrayList;
import java.util.List;

import model.card.Card;

/**
 * represents the main player in the three trios game.
 */
public class MainPlayer implements Player {

  List<Card> hand = new ArrayList<Card>();
  PlayerColor color;
  boolean currPlayer;
  int score;

  /**
   * constructor for a MainPlayer.
   *
   * @param color represents the color value of the player.
   * @param hand represents a player's hand.
   * @param currPlayer represents if they are the current player.
   */
  public MainPlayer(PlayerColor color, List<Card> hand, boolean currPlayer, int score) {
    if (color == null) {
      throw new IllegalArgumentException("Color is null!");
    }

    this.color = color;
    this.hand = hand;
    this.currPlayer = currPlayer;
    this.score = score;
  }

  @Override
  public List<Card> getHand() {
    return this.hand;
  }

  @Override
  public void setHand(List<Card> hand) {
    this.hand = hand;
  }

  @Override
  public boolean getIfCurrPlayer() {
    return this.currPlayer;
  }

  @Override
  public void setIfCurrPlayer(boolean currPlayer) {
    this.currPlayer = currPlayer;
  }

  @Override
  public PlayerColor getColor() {
    return this.color;
  }

  @Override
  public int getScore() {
    return this.score;
  }

  @Override
  public void setScore(int score) {
    this.score = score;
  }
}
