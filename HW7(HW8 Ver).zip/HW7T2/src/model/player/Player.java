package model.player;

import java.util.List;

import model.card.Card;

/**
 * Represents a player in the Three Trios Game.
 */
public interface Player {

  /**
   * Used to get a player's hand.
   *
   * @return the player's hand.
   */
  List<Card> getHand();

  /**
   * Used to set a player's hand.
   */
  void setHand(List<Card> hand);

  /**
   * Used to get if a player is the current player.
   *
   * @return if the player is the current player.
   */
  boolean getIfCurrPlayer();

  /**
   * Used to set if a player is the current player.
   */
  void setIfCurrPlayer(boolean currPlayer);

  /**
   * Used to access the player's color.
   *
   * @return the player's color.
   */

  PlayerColor getColor();

  /**
   * Used to get the score of the player.
   *
   * @return the player's score
   */

  int getScore();

  /**
   * Used to set the score of the player.
   *
   * @param score represents the int that the player's score will be set to.
   */

  void setScore(int score);

}
