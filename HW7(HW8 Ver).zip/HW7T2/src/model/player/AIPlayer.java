package model.player;

import java.util.List;

import model.ThreeTriosModel;
import model.ThreeTsModel;
import model.card.Card;
import model.cell.ICell;
import model.strategies.Strategy;

/**
 * Class that represents the AIPlayer in the ThreeTrios Game, implements the Player interface.
 */
public class AIPlayer implements Player {

  private final PlayerColor color;
  private List<Card> hand;
  private boolean currPlayer;
  private int score;
  private final Strategy strategy;

  /**
   * Constructor for AIPlayer.
   *
   * @param color    the player's color.
   * @param model    the game model.
   * @param strategy the strategy to use for making moves.
   */
  public AIPlayer(PlayerColor color, ThreeTsModel model, Strategy strategy) {
    if (color == null || model == null || strategy == null) {
      throw new IllegalArgumentException("Color, model, or strategy cannot be null.");
    }
    this.color = color;
    this.strategy = strategy;
    this.hand = model.getCurrPlayer().getHand();
    this.currPlayer = false;
    this.score = 0;
  }

  @Override
  public List<Card> getHand() {
    return hand;
  }

  @Override
  public void setHand(List<Card> hand) {
    this.hand = hand;
  }

  @Override
  public boolean getIfCurrPlayer() {
    return currPlayer;
  }

  @Override
  public void setIfCurrPlayer(boolean currPlayer) {
    this.currPlayer = currPlayer;
  }

  @Override
  public PlayerColor getColor() {
    return color;
  }

  @Override
  public int getScore() {
    return score;
  }

  @Override
  public void setScore(int score) {
    this.score = score;
  }

  /**
   * Executes AI turn by selecting card and cell to place it in.
   * Uses assigned strategy to make decisions.
   *
   * @param model The current game model.
   */
  public void playTurn(ThreeTriosModel model) {
    if (!currPlayer) {
      throw new IllegalStateException("It is not the AI's turn.");
    }

    Card selectedCard = strategy.selectCard(model);
    if (selectedCard == null) {
      throw new IllegalStateException("AI could not select a valid card.");
    }

    ICell selectedCell = strategy.selectCell(selectedCard);
    if (selectedCell == null) {
      throw new IllegalStateException("AI could not select a valid cell.");
    }

    int row = model.getGrid().getGridCells().indexOf(selectedCell) / model.getGrid().getNumCols();
    int col = model.getGrid().getGridCells().indexOf(selectedCell) % model.getGrid().getNumCols();

    model.placeCard(row, col, selectedCard);
    hand.remove(selectedCard);

    System.out.println("AI placed card at row " + row + ", col " + col);
  }
}
