package model.player;

/**
 * Represents each player's card color.
 */
public enum PlayerColor {
  RED,
  BLUE
}
