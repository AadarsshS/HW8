package model.grid;

import java.util.List;

import model.card.Card;
import model.cell.ICell;

/**
 * interface for a grid in the Three Trios Game.
 * we use a 1-based indexing when referring to a row or column on the grid.
 */
public interface IGrid {

  /**
   * Method that places a card on the Three Trios Game grid.
   *
   * @param row  represents the row on the grid.
   * @param col  represents the column on the grid.
   * @param card represents the card being placed on the grid.
   */
  void placeCard(int row, int col, Card card);

  /**
   * Method that gets a cell from the ThreeTrios Game grid.
   *
   * @param row represents the row on the grid.
   * @param col represents the column on the grid.
   * @return cell in the inputted position.
   */
  ICell getCell(int row, int col);

  /**
   * Returns the cell to the right of a given cell.
   *
   * @param cell represents the given cell.
   * @return the cell to the right the given cell.
   */
  ICell getCellRight(ICell cell);

  /**
   * Returns the cell to the left of a given cell.
   *
   * @param cell represents the given cell.
   * @return the cell to the left the given cell.
   */
  ICell getCellLeft(ICell cell);

  /**
   * Returns the cell above of a given cell.
   *
   * @param cell represents the given cell.
   * @return the cell above the given cell.
   */
  ICell getCellAbove(ICell cell);

  /**
   * Returns the cell on below of a given cell.
   *
   * @param cell represents the given cell.
   * @return the cell on below of the given cell.
   */

  ICell getCellBelow(ICell cell);

  /**
   * executes the cell battle on the grid.
   *
   * @param cell represents the starting cell of the cell battle.
   */

  void cellBattle(ICell cell);

  /**
   * gets the number of rows in a grid.
   *
   * @return the number of rows in the grid.
   */
  int getNumRows();

  /**
   * gets the number of cols in a grid.
   *
   * @return the number of cols in the grid.
   */
  int getNumCols();

  /**
   * gets the grid size.
   *
   * @return the number of cells in the grid.
   */
  int getGridSize();

  /**
   * returns how many cells on the grid are red.
   *
   * @return the number of red cells on the grid.
   */
  int getNumRed();

  /**
   * returns how many cells on the grid are blue.
   *
   * @return the number of blue cells on the grid.
   */
  int getNumBlue();

  /**
   * returns how many cells on the grid are blue.
   *
   * @return the number of cells in the grid.
   */
  List<ICell> getGridCells();
}
