package model.grid;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import model.card.Card;
import model.cell.Cell;
import model.cell.Hole;
import model.cell.ICell;
import model.player.PlayerColor;

/**
 * represents a grid in the ThreeTrios Game.
 */
public class Grid implements IGrid {

  int numRows;
  int numCols;
  List<ICell> grid = new ArrayList<ICell>();

  /**
   * Construction for a grid.
   *
   * @param rows represents the number of rows in the grid.
   * @param cols represents the number of cols in the grid.
   * @param grid represents the list of cells in the grid.
   */
  public Grid(int rows, int cols, List<ICell> grid) {
    //Exceptions
    if (rows < 1) {
      throw new IllegalArgumentException("Invalid number of rows to initiate grid!");
    }
    if (cols < 1) {
      throw new IllegalArgumentException("Invalid number of cols to initiate grid!");
    }
    if (grid == null) {
      throw new IllegalArgumentException("Invalid list of cells!");
    }

    //set the variables
    this.numRows = rows;
    this.numCols = cols;
    this.grid = grid;
  }

  @Override
  public void placeCard(int row, int col, Card card) {
    //Exceptions
    if (row < 0 || col < 0 || row > numRows || col > numCols) {
      throw new IllegalArgumentException("Invalid row or column for set cell!");
    }

    ICell cellPlacement = this.getCell(row, col);
    if (cellPlacement instanceof Hole) {
      throw new IllegalArgumentException("You can't place on a hole!");
    }
    if (cellPlacement.getCard().isPresent()) {
      throw new IllegalArgumentException("You can't place on a cell with a card");
    }

    //implementation
    int index = numCols * row + col;
    this.grid.set(index, new Cell(Optional.ofNullable(card)));
    this.cellBattle(getCell(row, col));
  }

  @Override
  public ICell getCell(int row, int col) {
    //exceptions
    if (row < 0 || col < 0 || row > numRows || col > numCols) {
      throw new IllegalArgumentException("Invalid row or column for get cell!");
    }

    int index = numCols * row + col;
    return this.grid.get(index);
  }

  @Override
  public ICell getCellRight(ICell cell) {
    int currentPosition = grid.indexOf(cell);
    if ((currentPosition % numCols) == (numCols - 1) || currentPosition == -1) {
      return new Cell(Optional.empty());
    }
    return grid.get(currentPosition + 1);
  }

  @Override
  public ICell getCellLeft(ICell cell) {
    int currentPosition = grid.indexOf(cell);
    if ((currentPosition % numCols) == 0 || currentPosition == -1) {
      return new Cell(Optional.empty());
    }
    return grid.get(currentPosition - 1);
  }

  @Override
  public ICell getCellAbove(ICell cell) {
    int currentPosition = grid.indexOf(cell);
    if (currentPosition < numCols || currentPosition == -1) {
      return new Cell(Optional.empty());
    }
    return grid.get(currentPosition - numCols);
  }

  @Override
  public ICell getCellBelow(ICell cell) {
    int currentPosition = grid.indexOf(cell);
    if (currentPosition >= (numRows * numCols) - numCols || currentPosition == -1) {
      return new Cell(Optional.empty());
    }
    return grid.get(currentPosition + numCols);
  }

  @Override
  public void cellBattle(ICell cell) {
    ICell rightCell = this.getCellRight(cell);
    ICell leftCell = this.getCellLeft(cell);
    ICell aboveCell = this.getCellAbove(cell);
    ICell belowCell = this.getCellBelow(cell);

    cell.rightBattle(rightCell, this);
    cell.leftBattle(leftCell, this);
    cell.aboveBattle(aboveCell, this);
    cell.belowBattle(belowCell, this);
  }

  @Override
  public int getNumRows() {
    return this.numRows;
  }

  @Override
  public int getNumCols() {
    return this.numCols;
  }

  @Override
  public int getGridSize() {
    return this.grid.size();
  }

  @Override
  public int getNumRed() {
    int numRed = 0;

    for (ICell c : grid) {
      if (c.getCard().isPresent()) {
        Card card = c.getCard().get();
        if (card.getColor().equals(PlayerColor.RED)) {
          numRed++;
        }
      }
    }
    return numRed;
  }

  @Override
  public int getNumBlue() {
    int numBlue = 0;

    for (ICell c : grid) {
      if (c.getCard().isPresent()) {
        Card card = c.getCard().get();
        if (card.getColor().equals(PlayerColor.BLUE)) {
          numBlue ++;
        }
      }
    }

    return numBlue;
  }

  @Override
  public List<ICell> getGridCells() {
    return this.grid;
  }
}
