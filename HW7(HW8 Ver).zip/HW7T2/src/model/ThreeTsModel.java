package model;

import java.io.FileNotFoundException;

import controller.ModelStatusListener;
import model.card.Card;

/**
 * Represents a Three Trios Game Model.
 */
public interface ThreeTsModel extends ReadonlyThreeTriosModel {

  /**
   * Helper method in startGame deals the deck out to the player's hands.
   */
  void dealDeck();

  /**
   * Method that places a card on the Three Trios Game grid.
   *
   * @param row  represents the row on the grid.
   * @param col  represents the column on the grid.
   * @param card represents the card being placed on the grid.
   */
  void placeCard(int row, int col, Card card);

  /**
   * Switches the current.
   */
  void switchCurrPlayer();

  /**
   * the grid file reader.
   * @param fileName represents the file that is being read.
   * @throws FileNotFoundException is an exception thrown if the given file does not exist.
   */
  void gridFileReader(String fileName) throws FileNotFoundException;

  /**
   * the card file reader.
   *
   * @param fileName represents the file that is being read.
   * @throws FileNotFoundException is an exception thrown if the given file does not exist.
   */
  void cardFileReader(String fileName) throws FileNotFoundException;

  /**
   * places a card from the AI Players hand strategically on a corner.
   */
  void cornerPlay();

  /**
   * places a card from the AI Player's hand strategically on the grid, so that they will flip the
   * most amount of cards.
   */
  void flipPlay();

  void addModelStatusListener(ModelStatusListener listener);

  void startGame();
}
