package model.strategies;

import model.ThreeTriosModel;
import model.card.Card;
import model.cell.ICell;

/**
 * Class that implements the MostFlips strategy.
 */
public class MostFlips implements Strategy {

  @Override
  public Card selectCard(ThreeTriosModel model) {
    return null;
  }

  @Override
  public ICell selectCell(Card selectedCard) {
    return null;
  }
}
