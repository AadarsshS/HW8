package model.strategies;

import java.util.List;

import model.ThreeTriosModel;
import model.ThreeTsModel;
import model.card.Card;
import model.cell.Hole;
import model.cell.ICell;
import model.player.Player;

/**
 * Class that represents the Corner strategy.
 */
public class Corner implements Strategy {

  ThreeTsModel model;
  int corner;

  /**
   * This represents a constructor for a corner strategy.
   * @param model represents the model-state that the strategy will be played on.
   */
  public Corner(ThreeTsModel model) {
    this.model = model;
  }

  @Override
  public ICell selectCell(Card selectedCard) {
    Player player = this.model.getCurrPlayer();

    if (!(this.model.getGrid().getCell(0, 0) instanceof Hole)
            && this.model.getGrid().getCell(0, 0).getCard().isEmpty()) {
      corner = 1;
      return this.model.getGrid().getCell(0, 0);
    } else if (!(this.model.getGrid().getCell(
            0, this.model.getGrid().getNumCols() - 1) instanceof Hole)
            && this.model.getGrid().getCell(
                    0, this.model.getGrid().getNumCols() - 1).getCard().isEmpty()) {
      corner = 2;
      return this.model.getGrid().getCell(0, this.model.getGrid().getNumCols() - 1);
    } else if (!(this.model.getGrid().getCell(
            this.model.getGrid().getNumRows() - 1, 0) instanceof Hole)
            && this.model.getGrid().getCell(
                    this.model.getGrid().getNumRows() - 1, 0).getCard().isEmpty()) {
      corner = 3;
      return this.model.getGrid().getCell(this.model.getGrid().getNumRows() - 1, 0);
    } else if (!(this.model.getGrid().getCell(this.model.getGrid().getNumRows() - 1,
            this.model.getGrid().getNumCols() - 1) instanceof Hole)
            && this.model.getGrid().getCell(this.model.getGrid().getNumRows() - 1,
            this.model.getGrid().getNumCols() - 1).getCard().isEmpty()) {
      corner = 4;
      return this.model.getGrid().getCell(
              this.model.getGrid().getNumRows() - 1,
              this.model.getGrid().getNumCols() - 1);
    }

    for (ICell c : this.model.getGrid().getGridCells()) {
      if ((!(c instanceof Hole) && c.getCard().isEmpty())) {
        return c;
      }
    }

    return null;
  }
  @Override

  public Card selectCard(ThreeTriosModel model) {
    if (corner == 1) {
      return findBestForTopLeft(model.getCurrPlayer().getHand());
    } else if (corner == 2) {
      return findBestForTopRight(model.getCurrPlayer().getHand());
    } else if (corner == 3) {
      return findBestForBottomLeft(model.getCurrPlayer().getHand());
    } else if (corner == 4) {
      return findBestForBottomRight(model.getCurrPlayer().getHand());
    } else {
      return model.getCurrPlayer().getHand().get(0);
    }
  }

  /**
   * finds the best card from a player's hand to place in the top left corner.
   *
   * @param hand the given cards in a hand.
   * @return the index in the hand that is best for the top left.
   */
  private Card findBestForTopLeft(List<Card> hand) {
    int max = -1;
    int maxIndex = 0;
    for (int cardIndex = 0; cardIndex < hand.size(); cardIndex++) {
      if ((hand.get(cardIndex).getEast() + hand.get(cardIndex).getSouth()) > max) {

        maxIndex = cardIndex;
        max = hand.get(cardIndex).getEast() + hand.get(cardIndex).getSouth();
      }
    }
    return hand.get(maxIndex);
  }

  /**
   * finds the best card from a player's hand to place on top right corner.
   *
   * @param hand the given cards in a hand.
   * @return the index in the hand that is best for the top right.
   */
  private Card findBestForTopRight(List<Card> hand) {
    int max = -1;
    int maxIndex = 0;
    for (int cardIndex = 0; cardIndex < hand.size(); cardIndex++) {
      if ((hand.get(cardIndex).getWest() + hand.get(cardIndex).getSouth()) > max) {
        maxIndex = cardIndex;
        max = hand.get(cardIndex).getWest() + hand.get(cardIndex).getSouth();
      }
    }
    return hand.get(maxIndex);
  }

  /**
   * finds the best card from a player's hand to place on bottom left corner.
   *
   * @param hand the given cards in a hand.
   * @return the index in the hand that is best for the bottom left.
   */
  private Card findBestForBottomLeft(List<Card> hand) {
    int max = -1;
    int maxIndex = 0;
    for (int cardIndex = 0; cardIndex < hand.size(); cardIndex++) {
      if ((hand.get(cardIndex).getEast() + hand.get(cardIndex).getNorth()) > max) {
        maxIndex = cardIndex;
        max = hand.get(cardIndex).getEast() + hand.get(cardIndex).getNorth();
      }
    }
    return hand.get(maxIndex);
  }

  /**
   * finds the best card from a player's hand to place on bottom right corner.
   *
   * @param hand the given cards in a hand.
   * @return the index in the hand that is best for the bottom right.
   */
  private Card findBestForBottomRight(List<Card> hand) {
    int max = -1;
    int maxIndex = 0;
    for (int cardIndex = 0; cardIndex < hand.size(); cardIndex++) {
      if ((hand.get(cardIndex).getWest() + hand.get(cardIndex).getSouth()) > max) {
        maxIndex = cardIndex;
        max = hand.get(cardIndex).getEast() + hand.get(cardIndex).getSouth();
      }
    }
    return hand.get(maxIndex);
  }
}
