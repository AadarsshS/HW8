package model.strategies;

import model.ThreeTriosModel;
import model.card.Card;
import model.cell.ICell;

/**
 * Interface that represents the strategies that the AIPlayer will be using.
 */
public interface Strategy {

  /**
   * Decides the selected card.
   * @param model represents the model that the computer player will be player on.
   * @return the card that fits the strategy.
   */
  Card selectCard(ThreeTriosModel model);

  /**
   * Decides which cell to play the selected card in.
   * @param selectedCard The card chosen to play.
   * @return The selected cell to play in.
   */
  ICell selectCell(Card selectedCard);
}
