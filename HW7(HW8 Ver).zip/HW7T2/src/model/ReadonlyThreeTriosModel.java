package model;

import model.card.Card;
import model.grid.IGrid;
import model.player.Player;

/**
 * Interface that represents the ThreeTrios Game but the immutable aspects of it.
 */
public interface ReadonlyThreeTriosModel {
  /**
   * Method that checks if the game is won.
   *
   * @return true if the game is won.
   */
  boolean isGameWon();

  /**
   * Method that checks if the game is over.
   *
   * @return true if the game is over.
   */
  boolean isGameOver();

  /**
   * Gets the current player in the game.
   *
   * @return the current player.
   */
  Player getCurrPlayer();

  /**
   * Gets the grid.
   *
   * @return the grid
   */

  IGrid getGrid();

  /**
   * returns the red player.
   */
  Player getRed();

  /**
   * returns the blue player.
   */
  Player getBlue();

  /**
   * Gets the number of cards that a player will flip if they place their card down at a specific
   * cell on the grid.
   *
   * @param card represents the card that will be placed down.
   * @param row represents the row that the card will be placed in.
   * @param col represents the col that the card will be placed in.
   * @return the number of cards that will be flipped if the player places their card down there.
   */
  int numCardsCanFlip(Card card, int row, int col);

}
