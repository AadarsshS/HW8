package controller;

/**
 * Interface representing listener for player actions in the Three Trios game.
 * Used by view and notifies controller when players perform actions.
 */
public interface PlayerActionListener {
  /**
   * Method that triggers when a player selects a card.
   *
   * @param card the selected card
   */
  void onCardSelect(model.card.Card card);

  /**
   * Method that triggers when a player selects a cell on the grid.
   *
   * @param row the row index of the selected cell
   * @param col the column index of the selected cell
   */
  void onCellSelect(int row, int col);
}
