package controller;

import model.player.PlayerColor;

/**
 * Interface representing listener for status updates of model in the Three Trios game.
 * Used by controller to receive notifications from the model.
 */
public interface ModelStatusListener {
  /**
   * Method that is triggered when the active player's turn changes.
   *
   * @param currentPlayer the color of the new active player
   */
  void onChangedTurn(PlayerColor currentPlayer);

  /**
   * Method that is triggered when the game is over.
   *
   * @param winner the winning player
   * @param winningScore the score of the winning player
   */
  void onGameOver(model.player.Player winner, int winningScore);
}
