package controller;

import model.ThreeTsModel;
import model.card.Card;
import model.player.Player;
import model.player.PlayerColor;
import view.ThreeTsGUI;

/**
 * Controller for Three Trios Game that implements the game's listeners
 */
public class ThreeTriosController implements PlayerActionListener, ModelStatusListener {

  private final ThreeTsModel model;
  private final Player player;
  private final ThreeTsGUI view;

  /**
   * Constructor for ThreeTriosController.
   *
   * @param model the game model
   * @param player the player this controller manages
   * @param view the view for this player
   */
  public ThreeTriosController(ThreeTsModel model, Player player, ThreeTsGUI view) {
    this.model = model;
    this.player = player;
    this.view = view;

    view.addPlayerActionListener(this);
    model.addModelStatusListener(this);
  }
  @Override
  public void onChangedTurn(PlayerColor currentPlayer) {
      view.updateTurn(currentPlayer);
  }

  @Override
  public void onGameOver(Player winner, int winningScore) {
    String message = String.format("Game Over! Winner: %s, Score: %d",
            winner.getColor(), winningScore);
    view.showMessage(message, "Game Over");
  }

  @Override
  public void onCardSelect(Card card) {
    if (!model.getCurrPlayer().equals(player)) {
      view.showMessage("It's not your turn!", "Invalid Action");
      return;
    }

    view.selectCard(card);
  }

  @Override
  public void onCellSelect(int row, int col) {
    if (!model.getCurrPlayer().equals(player)) {
      view.showMessage("It's not your turn!", "Invalid Action");
      return;
    }

    try {
      model.placeCard(row, col, view.getSelectedCard());
      view.updateBoard();
    } catch (IllegalArgumentException | IllegalStateException e) {
      view.showMessage(e.getMessage(), "Invalid Move");
    }
  }
}
